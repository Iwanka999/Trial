<?php

namespace App\Console\Commands;

use App\Jobs\GetDataFromBongaCashJob;
use App\Models\Config;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Services\Interfaces\RequestApiServiceInterface;

class GetDataFromBongaCashCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'get-data:'.Config::BONGA_CASH.' {limit}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'get data from bonga cam';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle(RequestApiServiceInterface $requestApiService)
    {
        $limit = $this->argument('limit');
        DB::beginTransaction();
        try {
            $config = Config::where('key', Config::BONGA_CASH)->first();
            $param = [
                'limit' => $limit
            ];
            if($config->is_active){
                $start = microtime(true);
                $data = $requestApiService->getData($config,$param);
                $requestApiService->saveData($data, $config);
                $time_elapsed_secs = microtime(true) - $start;
                Log::info("run GetDataFromBongaCashCommand $time_elapsed_secs");
            }
            DB::commit();
        } catch (\Exception $e) {
            Log::error(json_encode($e->getMessage()));
            DB::rollBack();
        }
//        GetDataFromBongaCashJob::dispatch($limit);
    }
}
