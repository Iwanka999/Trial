<?php

namespace App\Console\Commands;

use App\Jobs\UpdateCategoryFromStripcashJob;
use App\Models\Config;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Services\Interfaces\RequestApiServiceInterface;
class UpdateCategoryStripcashCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'update-category:'.Config::STRIP_CASH.' {limit}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'update category from strip cash';


    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle(RequestApiServiceInterface $requestApiService)
    {
        $limit = $this->argument('limit');
        DB::beginTransaction();
        try {
            $config = Config::where('key', Config::STRIP_CASH)->first();
            $param = [
                'limit' => $limit
            ];
            if($config->is_active){
                $start = microtime(true);

                $data = $requestApiService->getData($config,$param);
                $requestApiService->updateCategory($data, $config);

                $time_elapsed_secs = microtime(true) - $start;
                Log::info("run UpdateCategoryFromStripcashCommand $time_elapsed_secs");
            }
            DB::commit();
        } catch (\Exception $e) {
            Log::error(json_encode($e->getMessage()));
            DB::rollBack();
        }
//        UpdateCategoryFromStripcashJob::dispatch($limit);
    }
}
