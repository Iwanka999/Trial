<?php

namespace App\Console\Commands;

use App\Jobs\UpdateDataFromChaturbateJob;
use App\Models\Config;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Services\Interfaces\RequestApiServiceInterface;
class UpdateDataFromChaturbateCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'update-data:'.Config::CHATURBATE.' {limit}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'update data from chaturbate';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle(RequestApiServiceInterface $requestApiService)
    {
        $limit = $this->argument('limit');
        DB::beginTransaction();
        try {
            $config = Config::where('key', Config::CHATURBATE)->first();
            $param = [
                'limit' => $limit
            ];
            if($config->is_active){
                $start = microtime(true);

                $data = $requestApiService->getData($config,$param);
                $requestApiService->updateOnlineData($data, $config);

                $time_elapsed_secs = microtime(true) - $start;
                Log::info("run UpdateDataFromChaturbateCommand $time_elapsed_secs");
            }
            DB::commit();
        } catch (\Exception $e) {
            Log::error(json_encode($e->getMessage()));
            DB::rollBack();
        }
//        UpdateDataFromChaturbateJob::dispatch($limit);
    }
}
