<?php

namespace App\Console\Commands;

use App\Services\Interfaces\RequestApiServiceInterface;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class UpdateUniqueUserNameCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'update-data:unique-user-name';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Update user has duplicate name';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle(RequestApiServiceInterface $requestApiService)
    {
        $start = microtime(true);
        $requestApiService->handleDuplicateUsername();
        $time_elapsed_secs = microtime(true) - $start;
        Log::info("run UpdateUniqueUserNameCommand $time_elapsed_secs");
    }
}
