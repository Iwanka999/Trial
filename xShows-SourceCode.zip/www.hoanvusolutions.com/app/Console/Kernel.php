<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        Commands\GetDataFromBongaCashCommand::class,
        Commands\GetDataFromStripcashCommand::class,
        Commands\GetDataFromXLoveCashCommand::class,
        Commands\GetDataFromChaturbateCommand::class,

        Commands\UpdateDataFromXLoveCashCommand::class,
        Commands\UpdateDataFromStripcashCommand::class,
        Commands\UpdateDataFromChaturbateCommand::class,
        Commands\UpdateDataFromBongaCashCommand::class,

        Commands\UpdateCategoryBongaCashCommand::class,
        Commands\UpdateCategoryChaturbateCommand::class,
        Commands\UpdateCategoryStripcashCommand::class,
        Commands\UpdateCategoryXLoveCashCommand::class,

        Commands\UpdateUniqueUserNameCommand::class,
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
//        $schedule->command(Commands\GetDataCommand::class)->mondays()->at('7:00');
        $schedule->command(Commands\GetDataFromBongaCashCommand::class, [1000])->everySixHours();
        $schedule->command(Commands\GetDataFromStripcashCommand::class, [1000])->everySixHours();
        $schedule->command(Commands\GetDataFromXLoveCashCommand::class, [1000])->everySixHours();
        $schedule->command(Commands\GetDataFromChaturbateCommand::class, [1000])->everySixHours();
////
        $schedule->command(Commands\UpdateDataFromXLoveCashCommand::class, [1000])->everyThreeMinutes();
        $schedule->command(Commands\UpdateDataFromStripcashCommand::class, [1000])->everyThreeMinutes();
        $schedule->command(Commands\UpdateDataFromChaturbateCommand::class, [1000])->everyThreeMinutes();
        $schedule->command(Commands\UpdateDataFromBongaCashCommand::class, [1000])->everyThreeMinutes();
//
        $schedule->command(Commands\UpdateCategoryBongaCashCommand::class, [1000])->dailyAt("3:00");
        $schedule->command(Commands\UpdateCategoryChaturbateCommand::class, [1000])->dailyAt("3:00");
        $schedule->command(Commands\UpdateCategoryStripcashCommand::class, [1000])->dailyAt("3:00");
        $schedule->command(Commands\UpdateCategoryXLoveCashCommand::class, [1000])->dailyAt("3:00");
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
