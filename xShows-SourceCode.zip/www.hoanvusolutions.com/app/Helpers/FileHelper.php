<?php

namespace App\Helpers;
use File;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;

class FileHelper
{
    public static function removeFile($path){
        if (file_exists($path)) {
            unlink($path);
        }
    }

    public static function uploadFileContent($file , $path ){
        $fileName = Str::slug( Str::random(12).'_'.time()). ".jpg";
        File::put($path . $fileName, $file);
        $filePath = $path  . $fileName;
        return $filePath;
    }


    public static function uploadFile($file , $path, $name = null ){
        if(empty($name)){
            $fileName = Str::slug( Str::random(10).'_'.time()) .".".  $file->getClientOriginalExtension();
        }else{
            $fileName = $name;
        }
        $file->move( public_path( $path) , $fileName);
        $filePath = $path  . $fileName;
        return $filePath;
    }

    public static function uploadFileBase64($param, $folder){
        list($extension, $content) = explode(';', $param);
        $tmpExtension = explode('/', $extension);
        preg_match('/.([0-9]+) /', microtime(), $m);
        $fileName = sprintf('img%s%s.%s', date('YmdHis'), $m[1], $tmpExtension[1]);
        $content = explode(',', $content)[1];
        $storage = Storage::disk('public');

        $checkDirectory = $storage->exists($folder);

        if (!$checkDirectory) {
            $storage->makeDirectory($folder);
        }

        $filePath = $folder . '/' . $fileName;
        $storage->put($filePath, base64_decode($content), 'public');

        return $filePath;
    }
}
