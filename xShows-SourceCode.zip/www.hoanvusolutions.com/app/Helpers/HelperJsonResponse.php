<?php

namespace App\Helpers;

use Illuminate\Contracts\Support\Arrayable;
use Symfony\Component\HttpFoundation\Response as SymfonyResponse;

class HelperJsonResponse extends SymfonyResponse
{

    /**
     * Trả về json dành cho api theo 1 cấu trúc thống nhất.
     *
     * @param  array|\Illuminate\Contracts\Support\Arrayable  $data
     * @param  string  $message
     * @param  int $code
     * @return \Illuminate\Http\JsonResponse
     */
    public function jResponse($data, $message = 'Success.', $code = 200)
    {
        if (! isset($data) || empty($data)) {
            $data = [];
        }

        if (is_object($data) && $data instanceof Arrayable) {
            $data = $data->toArray();
        }

        return response()->json([
            'code' => $code,
            'status' => self::$statusTexts[$code],
            'message' => $message,
            'data' => $data
        ]);
    }
}
