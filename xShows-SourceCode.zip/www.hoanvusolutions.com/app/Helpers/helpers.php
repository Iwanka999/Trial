<?php

use App\Models\Config;
use App\Helpers\HelperJsonResponse;


if (!function_exists('handleIframeXloveCash')) {
    function handleIframeXloveCash($userName, $config)
    {
        $configData = (array)json_decode($config->data);
        $link = "https://prm03.wlresources.com/livechatiframe?d=";
        $configIframe = '{
                      "ui": {
                        "id_affilie": "%u",
                        "cf": "990000",
                        "caf": "7c747c7d",
                        "cac": "fff",
                        "tlt": "7f0000",
                        "cc": "990000",
                        "ct": "fff",
                        "ca": "99000082",
                        "psm": "%s",
                        "iframeVersion": true,
                        "displayLogo": false,
                        "quickFilters": false,
                        "topLinks": false,
                        "modelSuggestion": false,
                        "textChat": false,
                        "linkNewPage": false,
                        "tri": 10
                      },
                      "domId": "domToInjectTheWidgetwohmp3g3kba",
                      "resourcesUrl": "https://s4.wlresources.com",
                      "promotoolUrl": "https://prm03.wlresources.com",
                      "cacheBuster": "167298"
                    }';
        $encode = base64_encode(sprintf($configIframe, $configData["authItemId"], $userName));
        return $link.$encode;
    }
}

function getRoomData($userName){
    $client = new \GuzzleHttp\Client();
    $url = "https://bongacams.com/tools/amf.php";
    $res = $client->request("POST", $url, [
        "form_params" => [
            'method' => 'getRoomData',
            'args' => [$userName,true],
        ],
        'headers' => [
            'X-Requested-With' => 'XMLHttpRequest'
        ]
    ]);
    if ($res->getStatusCode() == 200) {
        $body = json_decode($res->getBody(), true);
        return $body;
    }
    return null;
}

if (!function_exists('handleLiveChat')) {
    function handleLiveChat($data, $home = false) {
        switch ($data['source']){
            case \App\Models\Config::XLOVE_CASH:
                $config = Config::where('key', Config::XLOVE_CASH)->first();
                return view('components.iframeXlovecash', [
                    'link' => handleIframeXloveCash($data['user_name'], $config)
                ]);
                break;
            case \App\Models\Config::BONGA_CASH:
                // https://db.bngpt.com/stream_AmandaWhite
                $dataRoom = getRoomData($data['user_name']);

                $localData = $dataRoom['localData'];
                $serverUrl = "https://" . str_replace('//', '', $localData["videoServerUrl"]);
                $link = $serverUrl."/hls/stream_$data[user_name]/public/stream_$data[user_name]/chunks.m3u8";
                return view('components.iframeBongaCash', [
                    'name' => $data['display_name'],
                    'link' => $link
                ]);
                break;
            case \App\Models\Config::STRIP_CASH:
                $modelJson = (array)json_decode($data['json_data']);
                $stream = (array)$modelJson['stream'];
                return view('components.iframeStripcash', [
                    'link' => $stream['url']
                ]);
                break;
            case \App\Models\Config::CHATURBATE:
                $config = Config::where('key', Config::CHATURBATE)->first();
                $dataConfig = (array)json_decode($config->data);
                $link = "https://chaturbate.com/embed/".$data['user_name']."/?join_overlay=1&campaign=".$dataConfig['wm']."&embed_video_only=1&disable_sound=1&tour=".$dataConfig['tour']."&mobileRedirect=auto";
//                $link = "https://chaturbate.com/in/?track=embed&tour=".$dataConfig['tour']."&campaign=".$dataConfig['wm']."&disable_sound=1&mobileRedirect=auto&embed_video_only=1&b=".$data['user_name'];
              return view('components.iframeChaturbate', [
                    'link' => $link
                ]);
                break;
        }
    }
}

if (!function_exists('getDataInJson')) {
    function getDataInJson($model, $jsonColumn) {
        $modelJson = (array)json_decode($model['json_data']);
        return $modelJson[$jsonColumn];
    }
}


if (!function_exists('apiError')) {
    function apiError($msg, $errors = null, $code = 422) {
        return apiRes(false, $msg, '', $errors, $code);
    }
}

if (!function_exists('apiRes')) {

    function apiRes($status, $message, $data, $error, $code) {
        $apiResp = [];
        $apiResp['status'] = $code  ? $code : 200;
        $apiResp['data'] = $data;
        $apiResp['msg'] = $message;
        $apiResp['errors'] = $error;
        return response($apiResp, $code ? $code : 200);
    }
}

if (!function_exists('apiOk')) {
    function apiOk($data, $list = false, $message = '') {
        if (!$list) {
            return apiRes(true, $message, $data, null, null);
        } else {
            $data = $data->toArray();

            $data['status'] = 'success';

            $data['msg'] = $message;
            $data['errors'] = null;

            //return response($apiResp, $code ? $code : ($status ? 200 : 500));
            // Mobile library friendly with 200 response only: https://github.com/Alamofire/Alamofire
            return response($data, 200);
        }
    }
}


if (! function_exists('active_menu()')) {
    function active_menu($routes, $class = 'active')
    {
        $currentRoute = Route::currentRouteName();
        if (is_array($routes)) {
            $routeList = array_keys($routes);
            if (in_array($currentRoute, $routeList)) {
                return $class;
            }
        } else {
            if ($routes == $currentRoute) {
                return $class;
            }
        }
    }
}

if (! function_exists('render_menu_item')) {
    function render_menu_item($routes)
    {
        $items = '';
        if (! empty($routes)) {
            foreach ($routes as $route => $text) {
                $items .= '<li class="nav-item"><a href="'.route($route).'" class="nav-link '.active_menu($route).'">'.
                    '<i class="far fa-circle nav-icon"></i><p>'.$text.'</p></a></li>';
            }
        }

        return $items;
    }
}

if (!function_exists('isAdmin')) {
    function isAdmin($user) {
        if($user->role === \App\Models\User::ROLE_ADMIN){
            return true;
        }
        return false;
    }
}

if (! function_exists('jRes')) {
    /**
     * Trả về json dành cho api theo 1 cấu trúc thống nhất.
     *
     * @param  array|\Illuminate\Contracts\Support\Arrayable  $data
     * @param  string  $message
     * @param  int $code
     * @return \Illuminate\Http\JsonResponse
     */
    function jRes($data, $message = 'Success.', $code = 200)
    {
        return (new HelperJsonResponse)->jResponse($data, $message, $code);
    }
}
