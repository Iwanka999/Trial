<?php

namespace App\Http\Controllers\Admin;


use App\Http\Requests\UpdateApiConfigRequest;
use App\Models\Config;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\DataTables;
use App\Models\User;


class AdminController
{
    private $model;
    private $user;

    public function __construct(Config $config,User $user)
    {
        $this->model = $config;
        $this->user = $user;

    }
    public function home(Request $request)
    {
        $configs = Config::all();
        return view('admin.config.index', ['configs' => $configs]);
    }

    public function updateStatus(Request $request, $id)
    {
        $data = $request->only(['status']);
        $model = $this->model->find($id);

        if (empty($model)) {
            return apiError("API not found");
        }

        $model->is_active = $data['status'];
        $model->save();

        return apiOk($model);
    }

    public function edit($id)
    {
        $model = $this->model->find($id);
        if ($model) {
            $dataConfig = (array)json_decode($model->data);
            return apiOk($dataConfig);
        }
        return apiError('Data not found');
    }

    public function update(UpdateApiConfigRequest $request, $id)
    {
        $model = $this->model->find($id);
        if (empty($model)) {
            return apiError("Data not found");
        }
        $data = $request->all();
        unset($data['_token']);

        DB::beginTransaction();
        try {
            $dataConfig = (array)json_decode($model->data);
            $model->data = json_encode(array_merge($dataConfig, $data));
            $model->save();
            DB::commit();
            return apiOk($model);
        } catch (\Exception $e) {
            Log::channel('api_errors')->error(__CLASS__."@".__FUNCTION__ . "---".json_encode($e->getMessage()));
            DB::rollBack();
            return apiError('Error');
        }
    }


    public function userIndex(Request $request)
    {
        if ($request->ajax()) {
            $query = $this->user->getList();
            return Datatables::of($query)
                ->addColumn('action', function ($model) {
                    return view('admin.components.group-button', [
                        'edit' => route('users.edit', $model->id),
                        'delete' => route('users.destroy', $model->id),
                    ]);
                })
                ->make(true);
        }
        return view('users.index');
    }

}
