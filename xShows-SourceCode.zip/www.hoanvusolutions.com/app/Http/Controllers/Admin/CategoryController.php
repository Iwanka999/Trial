<?php
/**
 * Created by PhpStorm.
 * User: huynh
 * Date: 16-Aug-20
 * Time: 8:57 PM
 */

namespace App\Http\Controllers\Admin;

use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\DataTables;

class CategoryController
{
    /**
     * @var \App\Models\Category
     */
    private $model;

    public function __construct(Category $category)
    {
        $this->model = $category;
    }

    public function index(Request $request)
    {
        if ($request->ajax()) {
            $query = $this->model->orderBy('name');
            return Datatables::of($query)
                ->editColumn('is_active', function ($model) {

                    return view('admin.components.active-category', [
                        'model' => $model,
                        'link' => route('categories.updates-status', $model->id)
                    ]);
                })
                ->addColumn('action', function ($model) {
                    return view('admin.components.group-button', [
                        'editMetaTag' => [
                            'get' => route('categories.edit', $model->id),
                            'update' => route('categories.update', $model->id),
                        ]
                    ]);
                })
                ->rawColumns(['is_active'])
                ->make(true);
        }
        return view('admin.categories.index');
    }

    public function edit($id)
    {
        $model = $this->model->find($id);
        return apiOk($model);
    }

    public function update(Request $request,$id){
        $roles = [
            'description' => 'required',
            'keywords' => 'required',
            'title' => 'required',
        ];
        $validator = Validator::make(request()->all(), $roles);
        if ($validator->fails()) {
            return apiError($validator->errors()->first(), $validator->errors(), 422);
        }
        $model =  $this->model->find($id);
        if (empty($model)) {
            return apiError("Data not found");
        }
        DB::beginTransaction();
        try {
            $model->fill($request->all());
            $model->save();
            DB::commit();
            return apiOk($model);
        } catch (\Exception $e) {
            Log::channel('api_errors')->error(__CLASS__."@".__FUNCTION__ . "---".json_encode($e->getMessage()));
            DB::rollBack();
            return apiError('Update failed');
        }
    }

    public function updateStatus(Request $request, $id)
    {
        $data = $request->only(['status']);
        $model = $this->model->find($id);

        if (empty($model)) {
            return apiError("API not found");
        }

        $model->is_active = $data['status'];
        $model->save();

        return apiOk($model);
    }
}
