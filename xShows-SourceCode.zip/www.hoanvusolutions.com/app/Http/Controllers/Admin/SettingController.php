<?php

namespace App\Http\Controllers\Admin;

use App\Helpers\FileHelper;
use App\Http\Requests\UpdataShopRequest;
use App\Http\Requests\UpdateApiConfigRequest;
use App\Http\Requests\UpdateSettingRequest;
use App\Models\Config;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\DataTables;
use App\Models\User;

class SettingController
{
    private $model;
    private $user;

    public function __construct(Setting $setting,User $user)
    {
        $this->model = $setting;
        $this->user = $user;

    }

    public function edit()
    {
        $data = $this->model->get();
        return view('admin.setting.index',['data' => $data]);
    }

    public function update(UpdateSettingRequest $request)
    {
        $data = $request->only([
            'logo', 'title'
        ]);
        DB::beginTransaction();
        try {
            // update title
            $this->model->where('key','title')->update([
                'value' => $request->title
            ]);
            $this->model->where('key','google_analytics_code')->update([
                'value' => $request->google_analytics_code
            ]);

            $this->model->where('key','meta_keywords')->update([
                'value' => $request->meta_keywords
            ]);

            $this->model->where('key','meta_description')->update([
                'value' => $request->meta_description
            ]);

            if($request->has('logo')){
                $data['logo'] = FileHelper::uploadFile($request->logo, env('LOGO_PATH','images/logo/'));
                $oldLogo = $this->model->where('key','logo')->first();
                $oldLogoImage = $oldLogo->value;

                $this->model->where('key','logo')->update([
                    'value' => $data['logo']
                ]);
                FileHelper::removeFile($oldLogoImage);
            }

            DB::commit();
            return redirect()->route('settings.edit');
        } catch (\Exception $e) {
            Log::channel('api_errors')->error(__CLASS__."@".__FUNCTION__ . "---".json_encode($e->getMessage()));
            FileHelper::removeFile($data['avatar']);
            DB::rollBack();
            return redirect()->route('settings.edit');
        }
    }

}
