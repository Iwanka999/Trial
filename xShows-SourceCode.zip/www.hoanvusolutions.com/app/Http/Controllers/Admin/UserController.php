<?php
/**
 * Created by PhpStorm.
 * User: huynh
 * Date: 16-Aug-20
 * Time: 8:57 PM
 */

namespace App\Http\Controllers\Admin;

use App\Http\Requests\ChangePasswordRequest;
use App\Http\Requests\UpdateAdminRequest;
use App\Http\Requests\UpdateUserRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Yajra\DataTables\DataTables;


class UserController
{
    /**
     * @var \App\Models\User
     */
    private $user;

    public function __construct(User $user)
    {
        $this->user = $user;
    }


    public function index(Request $request)
    {
        if ($request->ajax()) {
            $query = User::where('role', User::ROLE_MEMBER )->withTrashed();
            return Datatables::of($query)
                ->addColumn('status', function ($model) {
                    if ($model->trashed()) {
                        return '<span class="badge bg-danger"> Inactive</span>';
                    }
                    return '<span class="badge bg-success"> Active</span>';
                })
                ->addColumn('action', function ($model) {
                    return view('admin.components.group-button', [
                        'model' => $model,
                        'changePassword' => route('users.changePassword', $model->id),
                        'edit' => [
                            'get' => route('users.edit', $model->id),
                            'update' => route('users.update', $model->id),
                        ],
                        'delete' => route('users.destroy', $model->id),
                        'restore' => route('users.restore', $model->id),
                    ]);
                })
                ->rawColumns(['status'])
                ->make(true);
        }
        return view('admin.users.index');
    }

    public function show(Request $request)
    {
        $data = $this->user->find($request->key);
        if (!$data) {
            return apiError('Data not found');
        }
        if(is_object(json_decode($data->value)) || is_array(json_decode($data->value))){
            $arr = [];
            foreach((array)json_decode($data->value) as $key => $val){
                $arr [] = (object)['key' => $key, 'value' => $val];
            }
            return apiOk($arr);
        }else{
            return apiOk($data->value);
        }
    }

    /**
     * Hiển thị thông tin user để chỉnh sửa.
     *
     * @param  int  $id
     * @return mixed
     */
    public function edit($id)
    {
        $data = $this->user->find($id);
        if (!$data) {
            return apiError('Data not found');
        }
        return apiOk($data);
    }

    /**
     * Cập nhật user.
     *
     * @param  \App\Http\Requests\UpdateUserRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateUserRequest $request, $id)
    {
        $user = $this->user->find($id);
        if (!$user) {
            return apiError('Data not found');
        }
        $user->name = strip_tags($request->name);
        $user->save();
        return apiOk(null ,null ,'Updated successfully');

    }

    public function changePassword(ChangePasswordRequest $request, $id){
        $user = $this->user->find($id);
        $user->password = Hash::make($request->password);
        $user->save();
        return apiOk(null ,null ,'Updated successfully');
    }

    /**
     * Cập nhật admin.
     *
     * @param  \App\Http\Requests\UpdateUserRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
        public function updateAdmin(UpdateAdminRequest $request)
    {
        $user = auth()->user();
        $user->name = strip_tags($request->name);
        $user->email = strip_tags($request->email);
        $user->save();
        return apiOk(null ,null ,'Updated successfully');
    }

    /**
     * Cập nhật admin.
     *
     * @param  \App\Http\Requests\UpdateUserRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function changePasswordAdmin(ChangePasswordRequest $request)
    {
        $user = auth()->user();
        $user->password = Hash::make($request->password);
        $user->save();
        return apiOk(null ,null ,'Updated successfully');
    }

    /**
     * Ajax xóa user.
     *
     * @param  int  $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy($id)
    {
        $user = User::find($id);

        if (is_null($user)) {
            return apiError( 'Data not found', null,404);
        }
        $user->delete();
        return apiOk( null,null,'Deleted successfully');
    }

    public function restore($id) {

        $user = User::withTrashed()->find($id);
        if ($user->restore()) {
            return apiOk( null,null,'Restore was successfully completed');
        } else {
            return apiError('Restore failed');
        }
    }
}
