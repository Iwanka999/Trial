<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Config;
use App\Repositories\Interfaces\CategoryRepositoryInterface;
use App\Repositories\Interfaces\ModelRepositoryInterface;
use App\Repositories\Interfaces\XLoveCashTagRepositoryInterface;
use App\Services\Interfaces\RequestApiServiceInterface;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;
class HomeController extends Controller
{
    protected $requestApiService;
    protected $scripCashService;
    protected $XLoveCamService;
    protected $modelRepository;
    protected $config;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
        RequestApiServiceInterface $requestApiService,
        XLoveCashTagRepositoryInterface $scripCashService,
        CategoryRepositoryInterface $XLoveCamService,
        ModelRepositoryInterface $modelRepository
    )
    {
        $this->XLoveCamService = $XLoveCamService;
        $this->scripCashService = $scripCashService;
        $this->modelRepository = $modelRepository;
        $this->requestApiService = $requestApiService;
        $this->config = new Config();
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request, $cate = null)
    {
        $allRequest = $request->all();
        if(!empty($cate)){
            $allRequest ['cate'] = $cate;
            $category = Category::where('name', $cate)->first();
        } else {
            $category = null;
        }

        $list = $this->modelRepository->paginate($request->all(), '21');

        $categories = Category::orderBy('display_name')->where('is_active',true)->get();

        return view('home', ['data' => $list, 'categories' => $categories, 'category' => $category]);
    }

    public function sex(Request $request, $sex)
    {
        $filter = [
            'sex' => $sex,
        ];
        if($request->has('cate')){
            $filter['cate'] = $request->cate;
        }
        $data = $this->modelRepository->paginate($filter);

        $categories = Category::orderBy('display_name')->get();
        return view('sex', ['data' => $data, 'categories' => $categories]);
    }

    public function favorites(Request $request)
    {
        $data = $this->modelRepository->favorites();
        return view('favorited', ['data' => $data]);
    }

    public function detail($uniqueUsername)
    {
        $model = $this->modelRepository->getByColumn('unique_user_name',$uniqueUsername);
        if (empty($model)) {
            abort(404);
        }
        $related = $this->modelRepository->related($model);

        return view('detail', ['data' => $model, 'related' => $related]);
    }

//    public function ajaxRelated($id)
//    {
//        $model = $this->modelRepository->get($id);
//        if (empty($model)) {
//            abort(404);
//        }
//        $related = $this->modelRepository->related($model);
//
//        $returnHTML = view('components.view-list-model')->with(['related' => $related])->render();
//        return response()->json(array('success' => true, 'html'=>$returnHTML));
////        return apiOk($related);
//    }

    public function attachFavourite($id)
    {
        $model = $this->modelRepository->get($id);
        if (empty($model)) {
            return apiError('Model not found', null, 404);
        }
        $user = auth()->user();
        DB::beginTransaction();
        try {
            if ($user->favouriteModels->contains($id)) {
                $user->favouriteModels()->detach($id);

                DB::commit();
                return apiOk(true,false,"Removed from favorites");
            } else {
                $user->favouriteModels()->attach($id);
                DB::commit();
                return apiOk(true,false,"Added to favorites");
            }

        } catch (\Exception $e) {
            Log::error(json_encode($e->getMessage()));
            Db::rollBack();
            return apiError('Server error', null, 500);
        }
    }

}
