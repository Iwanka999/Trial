<?php

namespace App\Http\Requests;

use App\Models\AppointmentStatus;
use App\Models\Config;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Support\Facades\Request;

class UpdateApiConfigRequest extends FormRequest
{
    private $id;
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $this->id = $this->route('id');
        return true;
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(apiError($validator->errors()->first(), $validator->errors(), 422));
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $config = Config::find($this->id);
        switch ($config->key){
            case Config::XLOVE_CASH:
                $rules = [
                    'authItemId' => 'required',
                    'authSecret' => 'required'
                ];
                break;
            case Config::BONGA_CASH:
                $rules = [
                    'c' => 'required',
                ];
                break;
            case Config::CHATURBATE:
                $rules = [
                    'wm' => 'required',
                ];
                break;
            case Config::STRIP_CASH:
                $rules = [
                    'userId' => 'required',
                ];
                break;
        }
        return $rules;
    }
}
