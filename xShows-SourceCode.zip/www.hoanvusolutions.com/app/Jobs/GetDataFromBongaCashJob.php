<?php

namespace App\Jobs;

use App\Models\Config;
use App\Services\Interfaces\RequestApiServiceInterface;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class GetDataFromBongaCashJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    protected $limit;
    public function __construct($limit)
    {
        $this->limit = $limit;
    }


    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle(RequestApiServiceInterface $requestApiService)
    {
        DB::beginTransaction();
        try {
            $config = Config::where('key', Config::BONGA_CASH)->first();
            $param = [
                'limit' => $this->limit
            ];
            if($config->is_active){
                $start = microtime(true);
                $data = $requestApiService->getData($config,$param);
                $requestApiService->saveData($data, $config);
                $time_elapsed_secs = microtime(true) - $start;
                Log::info("run GetDataFromBongaCashCommand $time_elapsed_secs");
            }
            DB::commit();
        } catch (\Exception $e) {
            Log::error(json_encode($e->getMessage()));
            DB::rollBack();
        }
    }
}
