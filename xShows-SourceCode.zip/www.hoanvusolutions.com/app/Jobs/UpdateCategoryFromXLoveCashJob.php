<?php

namespace App\Jobs;

use App\Models\Config;
use App\Services\Interfaces\RequestApiServiceInterface;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class UpdateCategoryFromXLoveCashJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    protected $limit;
    public function __construct($limit)
    {
        $this->limit = $limit;
    }


    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle(RequestApiServiceInterface $requestApiService)
    {
        DB::beginTransaction();
        try {
            $limit = $this->limit;
            $config = Config::where('key', Config::XLOVE_CASH)->first();
            $param = [
                'limit' => $limit
            ];
            if($config->is_active){
                $start = microtime(true);

                $data = $requestApiService->getData($config,$param);
                $requestApiService->updateCategory($data, $config);

                $time_elapsed_secs = microtime(true) - $start;
                Log::info("run UpdateCategoryFromXLoveCashCommand $time_elapsed_secs");
            }
            DB::commit();
        } catch (\Exception $e) {
            Log::error(json_encode($e->getMessage()));
            DB::rollBack();
        }
    }
}
