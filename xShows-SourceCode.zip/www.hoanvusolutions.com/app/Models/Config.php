<?php


namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Config extends Model
{
    CONST METHOD = [
        'GET' => 'query',
        'POST' => 'form_params'
    ];

    CONST STRIP_CASH ='stripcash';
    CONST XLOVE_CASH ='xlovecash';
    CONST CHATURBATE ='chaturbate';
    CONST BONGA_CASH ='bongacash';

    // s = trans
    // c = couple
    CONST STRIP_CASH_SEX = [
        'trans' => ['trans','s','femaleTranny',],
        'male' => ['men','male','m','M','Couple Female + Male','maleFemale'],
        'female' => ['female','F','f','Couple Female + Female','Couple Female + Male','Female','females','femaleTranny','maleFemale']
    ];

    protected $table = "config";
    protected $fillable = [
        'method', 'api_url','data'
    ];

    public function getActiveList()
    {
        return  $this->where('is_active',1)->get();
    }
}
