<?php
namespace App\Models;
use App\Traits\Filterable;
use Illuminate\Database\Eloquent\Model as EloquentModel;

class Model extends EloquentModel
{
    use Filterable;

    protected $table = 'models';

    protected $fillable = [
        'model_id',
        'user_name',
        'unique_user_name',
        'display_name',
        'age',
        'gender',
        'description',
        'image',
        'iframe',
        'is_online',
        'link_embed',
        'link_snapshot',
        'url_stream',
        'chat_url',
        'source',
        'json_data'
    ];

    protected $filterable = [
        'model_id',
        'user_name',
        'display_name',
        'age',
        'gender',
        'id',
    ];

    public function filterCate($query, $value){
        return $query->leftJoin('model_category','model_category.model_id','=','models.id')
                        ->leftJoin('categories','model_category.category_id','=','categories.id')
            ->where('categories.name',$value);
    }

    public function filterSex($query, $value){
        $arrGen = Config::STRIP_CASH_SEX[$value];
        return $query->where(function($query) use ($arrGen) {
            foreach ($arrGen as $gen) {
                $query->orWhere($this->table . '.gender', $gen);
            }
        });
    }

    public function users(){
        return $this->belongsToMany('App\Models\User', 'favourites', 'model_id','user_id');
    }

    public function categories(){
        return $this->belongsToMany('App\Models\Category', 'model_category', 'model_id','category_id');
    }
}
