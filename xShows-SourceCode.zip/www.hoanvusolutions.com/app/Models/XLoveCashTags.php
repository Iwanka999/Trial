<?php


namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class XLoveCashTags extends Model
{
    protected $table = "xlovecash_tags";

    protected $fillable = [
        'value', 'title'
    ];

}
