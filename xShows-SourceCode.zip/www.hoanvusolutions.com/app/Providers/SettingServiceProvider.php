<?php

namespace App\Providers;

use App\Models\Category;
use App\Models\Setting;
use Hamcrest\Core\Set;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class SettingServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
//        $allSetting = Setting::all();
//        foreach($allSetting as $setting){
//            View::share($setting->key."_global",$setting->value);
//        }

    }
}
