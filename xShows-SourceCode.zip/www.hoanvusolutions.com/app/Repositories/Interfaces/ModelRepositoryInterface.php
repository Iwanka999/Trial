<?php

namespace App\Repositories\Interfaces;

interface ModelRepositoryInterface
{
    public function get($id, $columns = array('*'));

    public function all($columns = array('*'));

    public function paginate($param = [], $perPage = 15, $columns = array('*'));

    public function save(array $data);

    public function saveMany(array $data);

    public function update(array $data, $id);

    public function updateByModelId(array $data, $modelId, $source);

    public function updateMany(array $data, array $where, array $arrayIds = [], $typeQuery = 'whereIn');

    public function getMany(array $where, array $arrayIds = []);

    public function getByColumn($column, $value);

    public function getByMultiColumn(array $where, $columnsSelected = array('*'));

    public function deleteByMultiColumn(array $where);

    public function getListByColumn($column, $value, $columnsSelected = array('*'));

    public function getListByMultiColumn(array $where, $columnsSelected = array('*'));

    public function delete($id);

    public function deleteMulti(array $data);

    public function filter($param = []);

    public function related($model);

    public function favorites($perPage = 20);

    public function getDuplicateUsername();

}
