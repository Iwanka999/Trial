<?php

namespace App\Repositories\Interfaces;

interface XLoveCashTagRepositoryInterface
{
    public function getByTags($tags);
}
