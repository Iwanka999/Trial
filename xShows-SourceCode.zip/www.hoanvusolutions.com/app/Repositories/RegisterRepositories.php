<?php

namespace App\Repositories;
use Illuminate\Support\ServiceProvider;
class RegisterRepositories extends ServiceProvider
{
    public function register()
    {
        $this->app->bind(
            'App\Repositories\Interfaces\ModelRepositoryInterface',
            'App\Repositories\Repository\ModelRepository'
        );

        $this->app->bind(
            'App\Repositories\Interfaces\CategoryRepositoryInterface',
            'App\Repositories\Repository\CategoryRepository'
        );

        $this->app->bind(
            'App\Repositories\Interfaces\XLoveCashTagRepositoryInterface',
            'App\Repositories\Repository\XLoveCashTagRepository'
        );
    }
}
