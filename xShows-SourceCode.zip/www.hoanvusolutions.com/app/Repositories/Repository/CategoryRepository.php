<?php

namespace App\Repositories\Repository;

use App\Models\Category;
use App\Models\Config;
use App\Repositories\Interfaces\CategoryRepositoryInterface;
use Illuminate\Support\Facades\DB;

class CategoryRepository implements CategoryRepositoryInterface
{
    private $category;

    public function __construct()
    {
        $this->category = new Category();
    }


    public function get($id, $columns = array('*'))
    {
        $data = $this->category->find($id, $columns);
        if ($data) {
            return $data;
        }
        return null;
    }

    public function all($columns = array('*'))
    {
        $listData = $this->category->get($columns);
        return $listData;
    }

    public function paginate($param = [], $perPage = 15, $columns = array('*'))
    {
        $listData = $this->category->paginate($perPage, $columns);
        return $listData;
    }

    public function save(array $data)
    {
        return $this->category->create($data);
    }

    public function update(array $data, $id)
    {
        $dep = $this->category->find($id);
        if ($dep) {
            foreach ($dep->getFillable() as $field) {
                if (array_key_exists($field, $data)) {
                    $dep->$field = $data[$field];
                }
            }
            if ($dep->save()) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public function getByColumn($column, $value, $columnsSelected = array('*'))
    {
        $data = $this->category->where($column, $value)->first();
        if ($data) {
            return $data;
        }
        return null;
    }

    public function getByMultiColumn(array $where, $columnsSelected = array('*'))
    {
        $data = $this->category;
        foreach ($where as $key => $value) {
            $data = $data->where($key, $value);
        }
        $data = $data->first();
        if ($data) {
            return $data;
        }
        return null;
    }

    public function getListByColumn($column, $value, $columnsSelected = array('*'))
    {
        $data = $this->category->where($column, $value)->get();
        if ($data) {
            return $data;
        }
        return null;
    }

    public function getListByMultiColumn(array $where, $columnsSelected = array('*'))
    {
        $data = $this->category;
        foreach ($where as $key => $value) {
            $data = $data->where($key, $value);
        }
        $data = $data->get();
        if ($data) {
            return $data;
        }
        return null;
    }

    public function delete($id)
    {
        $del = $this->category->find($id);
        if ($del !== null) {
            $del->delete();
            return true;
        } else {
            return false;
        }
    }

    public function deleteMulti(array $data)
    {
        $del = $this->category->whereIn("id", $data["list_id"])->delete();
        if ($del) {
            return true;
        } else {
            return false;
        }
    }

    public function filter($param = [])
    {
        $query = $this->category->filter($param)->select("*")->orderBy("created_at", "DESC");
        return $query;
    }

    public function countNumOfCancel($params = []){
        $del = $this->category->where($params)->count();
        return $del;
    }

    public function getByTags($tags){
        $query = $this->category->where(function($query) use ($tags) {
            foreach ($tags as $tag) {
                $tag = strip_tags($tag);
                $query->orWhereRaw(DB::raw("'$tag' LIKE CONCAT('%',categories.name,'%')"));
                $query->orWhereRaw(DB::raw("'$tag' LIKE CONCAT('%',REPLACE(categories.name,' ',''),'%')"));
            }
        });
        return $query->pluck('id')->toArray();
    }
}
