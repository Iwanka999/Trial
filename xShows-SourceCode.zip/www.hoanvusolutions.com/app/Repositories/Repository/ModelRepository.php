<?php

namespace App\Repositories\Repository;

use App\Models\Config;
use App\Models\Model;
use App\Models\Trip;
use App\Repositories\Interfaces\ModelRepositoryInterface;
use App\Utils\PaginationMerger;
use Illuminate\Support\Facades\DB;

class ModelRepository implements ModelRepositoryInterface
{
    private $model;
    private $config;

    public function __construct()
    {
        $this->model = new Model();
        $this->config = new Config();
    }


    public function get($id, $columns = array('*'))
    {
        $query = $this->model->where('models.id', $id);

        $currentUser = auth()->user();
        if ($currentUser) {
            $query->leftJoin('favourites', function($join) use ($currentUser)
            {
                $join->on('favourites.model_id','=','models.id');
                $join->on('favourites.user_id','=', DB::raw($currentUser->id) );
            })->select("models.*","favourites.id as favourite")
            ;
        }else{
            $query->select("models.*");
        }
        if ($query) {
            return $query->first();
        }
        return null;
    }

    public function all($columns = array('*'))
    {
        $listData = $this->model->get($columns);
        return $listData;
    }

    public function paginate($param = [], $perPage = 20, $columns = array('models.*'))
    {
        $currentUser = auth()->user();
        $allData = $this->model->filter($param)
            ->whereIn(
                'models.source',
                DB::table('config')->where('is_active',1)->pluck('key')
            )
            ->where('models.is_online',1)
            ->orderByRaw('RAND()')
        ;
        if ($currentUser) {
            $allData->leftJoin('favourites', function($join) use ($currentUser)
            {
                $join->on('favourites.model_id','=','models.id');
                $join->on('favourites.user_id','=', DB::raw($currentUser->id) );
            })->select("models.*","favourites.id as favourite")
            ;
        }else{
            $allData->select("models.*");
        }

        return $allData->paginate($perPage);
    }

//    public function paginate($param = [], $perPage = 20, $columns = array('models.*'))
//    {
//        $allApi = $this->config->where('is_active', 1)->get();
//        $limit = floor($perPage / count($allApi));
//        $currentUser = auth()->user();
//        $allData = [];
//        $numItems = count($allApi);
//        foreach ($allApi as $key => $api) {
//            if ($key == 0) {
//                $allData = $this->model->filter($param)->where('source', $api->key)->orderBy('models.is_online', 'DESC');
//                if ($currentUser) {
//                    $allData->select('models.*', DB::raw('(select s.user_id from favourites s where s.model_id = models.id AND s.user_id = ' . $currentUser->id . ') as favourite'));
//                }
//                $allData = $allData->paginate($limit);
////                var_dump($limit);
//            }else {
//                if($key == $numItems - 1) {
//                    $count = $perPage;
//                }else{
//                    $count = $limit * ($key + 1);
//                }
//                // first model limit 5
//                // second model limit perpage - count($data)
//                // third = perpage - count($data)
//                $subData = $this->model->filter($param)->where('source', $api->key)->orderBy('models.is_online', 'DESC');
//                if ($currentUser) {
//                    $subData->select('models.*', DB::raw('(select s.user_id from favourites s where s.model_id = models.id AND s.user_id = ' . $currentUser->id . ') as favourite'));
//                }
////                var_dump($count);
////                var_dump(count($allData));
////                var_dump($count - count($allData));
//                $subData = $subData->paginate($count - count($allData));
//                $allData = PaginationMerger::merge($allData, $subData);
//            }
////            if($key == 0){
////                if($offset != 0){
////                    $offset  += $excess;
////                }
////                $query = $this->model->filter($param)->where('source' , $api->key)
////                    ->orderBy('models.is_online','DESC')
////                    ->limit($limit + $excess)->offset($offset);
////                $offset = isset($param['page']) ?( $param['page'] - 1 ) * $limit : 0;
////            }else{
////                $subQuery = $this->model->filter($param)->where('source' , $api->key)
////                    ->orderBy('models.is_online','DESC')
////                    ->limit($limit)->offset($offset);
////                $query = $query->unionAll($subQuery);
////            }
//        }
//        return $allData;
//    }

    public function save(array $data)
    {
        return $this->model->create($data);
    }

    public function saveMany(array $data)
    {
        return $this->model->insert($data);
    }

    public function getMany(array $where, array $arrayIds = [])
    {
        $query = $this->model->where($where)->whereIn('model_id', $arrayIds);
        return $query->get();
    }


    public function updateMany(array $data, array $where, array $arrayIds = [], $typeQuery = 'whereIn')
    {
        $query = $this->model->where($where);
        if (!empty($arrayIds)) {
            $query->$typeQuery('model_id', $arrayIds);
        }
        return $query->update($data);
    }

    public function updateByModelId(array $data, $modelId, $source)
    {
        $dep = $this->model->where('model_id', $modelId)->where('source', $source)->first();
        if ($dep) {
            foreach ($dep->getFillable() as $field) {
                if (array_key_exists($field, $data)) {
                    $dep->$field = $data[$field];
                }
            }
            if ($dep->save()) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public function update(array $data, $id)
    {
        $dep = $this->model->find($id);
        if ($dep) {
            foreach ($dep->getFillable() as $field) {
                if (array_key_exists($field, $data)) {
                    $dep->$field = $data[$field];
                }
            }
            if ($dep->save()) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public function getByColumn($column, $value, $columnsSelected = array('*'))
    {
        $data = $this->model->where($column, $value)->first();
        if ($data) {
            return $data;
        }
        return null;
    }

    public function deleteByMultiColumn(array $where)
    {
        $data = $this->model->where($where)->delete();
        return $data;
    }

    public function getByMultiColumn(array $where, $columnsSelected = array('*'))
    {
        $data = $this->model;
        foreach ($where as $key => $value) {
            $data = $data->where($key, $value);
        }
        $data = $data->first();
        if ($data) {
            return $data;
        }
        return null;
    }

    public function getListByColumn($column, $value, $columnsSelected = array('*'))
    {
        $data = $this->model->where($column, $value)->get();
        if ($data) {
            return $data;
        }
        return null;
    }

    public function getListByMultiColumn(array $where, $columnsSelected = array('*'))
    {
        $data = $this->model;
        foreach ($where as $key => $value) {
            $data = $data->where($key, $value);
        }
        $data = $data->get();
        if ($data) {
            return $data;
        }
        return null;
    }

    public function delete($id)
    {
        $del = $this->model->find($id);
        if ($del !== null) {
            $del->delete();
            return true;
        } else {
            return false;
        }
    }

    public function deleteMulti(array $data)
    {
        $del = $this->model->whereIn("id", $data["list_id"])->delete();
        if ($del) {
            return true;
        } else {
            return false;
        }
    }

    public function filter($param = [])
    {
        $query = $this->model->filter($param)->select("*")->orderBy("created_at", "DESC");
        return $query;
    }

    public function related($model)
    {
        $query = $this->model
            ->where([
                'source' => $model->source,
                'gender' => $model->gender,
            ])
            ->where('models.model_id', '<>', $model->model_id)
            ->orderBy('models.is_online', 'DESC');

        $currentUser = auth()->user();
        if ($currentUser) {
            $query->leftJoin('favourites', function($join) use ($currentUser)
            {
                $join->on('favourites.model_id','=','models.id');
                $join->on('favourites.user_id','=', DB::raw($currentUser->id) );
            })->select("models.*","favourites.id as favourite")
            ;
        }else{
            $query->select("models.*");
        }
//        if ($currentUser) {
//            $query->select('models.*', DB::raw('(select s.user_id from favourites s where s.model_id = models.id AND s.user_id = ' . $currentUser->id . ') as favourite'));
//        }
        return $query->limit(20)->get();
    }

    public function favorites($perPage = 20)
    {
        $currentUser = auth()->user();
        $query = $this->model
            ->leftJoin('favourites', function($join) use ($currentUser)
            {
                $join->on('favourites.model_id','=','models.id');
                $join->on('favourites.user_id','=', DB::raw($currentUser->id) );
            })
            ->where('favourites.user_id', $currentUser->id)
            ->select("models.*","favourites.id as favourite")
            ->orderBy('id', 'DESC')
            ->orderBy('models.is_online', 'DESC');
        return $query->paginate($perPage);
    }

    public function getDuplicateUsername(){
        return $this->model->distinct()->select('models.unique_user_name')
            ->join(DB::raw('
                (SELECT unique_user_name
               FROM models
               GROUP  BY unique_user_name
               HAVING COUNT(id) > 1) duplicate'),
            function($join)
            {
                $join->on('models.unique_user_name', '=', 'duplicate.unique_user_name');
            })
            ->limit(200)->get()->toArray();
    }

}
