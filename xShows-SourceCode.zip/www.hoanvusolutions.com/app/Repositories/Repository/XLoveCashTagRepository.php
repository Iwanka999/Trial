<?php

namespace App\Repositories\Repository;

use App\Models\XLoveCashTags;
use App\Repositories\Interfaces\XLoveCashTagRepositoryInterface;
use Illuminate\Support\Facades\DB;

class XLoveCashTagRepository implements XLoveCashTagRepositoryInterface
{
    private $xLoveCashTags;

    public function __construct()
    {
        $this->xLoveCashTags = new XLoveCashTags();
    }

    public function getByTags($tagIds){
        $query = $this->xLoveCashTags->whereIn('value',$tagIds)->whereNotNull('category_id');
        return $query->pluck('category_id')->toArray();
    }
}
