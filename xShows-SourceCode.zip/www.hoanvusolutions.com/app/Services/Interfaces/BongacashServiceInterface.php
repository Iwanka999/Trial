<?php
namespace App\Services\Interfaces;

interface BongacashServiceInterface
{
 public function performerOnlineList($param = array(), $updateProfile = false, $config = null) ;
}
