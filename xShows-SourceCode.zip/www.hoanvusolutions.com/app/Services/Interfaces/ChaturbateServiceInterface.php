<?php
namespace App\Services\Interfaces;

interface ChaturbateServiceInterface
{
 public function performerOnlineList($param = array(), $updateProfile = false, $config = null) ;
}
