<?php

namespace App\Services\Interfaces;

interface RequestApiServiceInterface
{
    public function getData($api, $filter = []);

    public function saveData($data, $config);
    public function updateOnlineData($data, $config);
    public function updateCategory($data, $config);
    public function handleDuplicateUsername();
}
