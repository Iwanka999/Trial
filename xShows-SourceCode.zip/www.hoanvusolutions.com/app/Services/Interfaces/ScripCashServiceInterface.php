<?php
namespace App\Services\Interfaces;

interface ScripCashServiceInterface
{
 public function performerOnlineList($param = array(), $updateProfile = false, $config = null);
}
