<?php
namespace App\Services\Interfaces;

interface XLoveCamServiceInterface
{
 public function performerOnlineList($param = array(), $performerCheckIsOnline = false, $performerProfileInfo = false) ;
 public function performerCheckIsOnline(array $modelIds) ;
 public function performerProfileInfo(array $modelIds) ;
}
