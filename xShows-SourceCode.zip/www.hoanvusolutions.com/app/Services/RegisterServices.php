<?php
namespace App\Services;
use Illuminate\Support\ServiceProvider;
class RegisterServices extends ServiceProvider
{
  public function register()
  {

      $this->app->bind(
          'App\Services\Interfaces\RequestApiServiceInterface',
          'App\Services\Service\RequestApiService'
      );

      $this->app->bind(
          'App\Services\Interfaces\ScripCashServiceInterface',
          'App\Services\Service\ScripCashService'
      );

      $this->app->bind(
          'App\Services\Interfaces\XLoveCamServiceInterface',
          'App\Services\Service\XLoveCamService'
      );

      $this->app->bind(
          'App\Services\Interfaces\ChaturbateServiceInterface',
          'App\Services\Service\ChaturbateService'
      );

      $this->app->bind(
          'App\Services\Interfaces\BongacashServiceInterface',
          'App\Services\Service\BongacashService'
      );
  }
}
