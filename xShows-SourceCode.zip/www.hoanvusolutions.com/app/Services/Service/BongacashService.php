<?php

namespace App\Services\Service;

use App\Models\Config;
use App\Repositories\Interfaces\ModelRepositoryInterface;
use App\Services\Interfaces\BongacashServiceInterface;
use App\Services\Interfaces\ChaturbateServiceInterface;
use App\Services\Interfaces\RequestApiServiceInterface;
use App\Services\Interfaces\ScripCashServiceInterface;

class BongacashService implements BongacashServiceInterface
{
    protected $modelRepository;
    protected $requestApiService;
    protected $api;

    public function __construct(
        ModelRepositoryInterface $modelRepository,
        RequestApiServiceInterface $requestApiService
    )
    {
        $this->modelRepository = $modelRepository;
        $this->requestApiService = $requestApiService;
    }

    protected function getConfig()
    {
        $config = Config::where('key', Config::BONGA_CASH)->first();
        return $config;
    }

    // limit =1000
    public function performerOnlineList($param = [], $updateProfile = false, $config = null)
    {
        if (empty($param)) {
            $param = [
                'limit' => 50
            ];
        }
        if(empty($config)){
            $config = $this->getConfig();
        }
        $data = $this->requestApiService->getData($config, $param);

        $modelIds = [];
        foreach ($data as $item) {
            $modelIds [] = $item['username'];
            $exists = $this->modelRepository->getByColumn('model_id', $item['username']);
            if (empty($exists)) {
                $model = [
                    'model_id' => $item['username'],
                    'user_name' => $item['username'],
                    'display_name' => $item['display_name'],
                    'age' => $item['display_age'],
                    'gender' => $item['gender'],
                    'description' => null,
                    'image' => "http://".str_replace('//','',$item['profile_images']['profile_image']),
                    'iframe' => null,
                    'link_embed' => $item['embed_chat_url'],
                    'link_snapshot' => $item['profile_images']['thumbnail_image_big_live'],
                    'chat_url' => $item['chat_url'],
                    'is_online' => true,
                    'source' => Config::BONGA_CASH,
                    'json_data' => json_encode($item),
                ];
                $this->modelRepository->save($model);
            } else {
                if($updateProfile) {
                    $update = [
                        'display_name' => $item['display_name'],
                        'age' => $item['display_age'],
                        'image' => "http://".str_replace('//','',$item['profile_images']['profile_image']),
                        'link_embed' => $item['embed_chat_url'],
                        'link_snapshot' => $item['profile_images']['thumbnail_image_big_live'],
                        'chat_url' => $item['chat_url'],
                        'is_online' => true,
                        'json_data' => json_encode($item)
                    ];
                    $exists->update($update);
                }
            }
        }

        if(!empty($modelIds)) {
            // update offline
            $dataUpdateOffline = [
                'is_online' => 0
            ];
            $where = [
                'source' => Config::BONGA_CASH
            ];
            $this->modelRepository->updateMany($dataUpdateOffline, $where, $modelIds, 'whereNotIn');

            // update online
            if(!$updateProfile) {
                $dataUpdateOnline = [
                    'is_online' => 0
                ];
                $where = [
                    'source' => Config::BONGA_CASH
                ];
                $this->modelRepository->updateMany($dataUpdateOnline, $where, $modelIds);
            }
        }
    }
}
