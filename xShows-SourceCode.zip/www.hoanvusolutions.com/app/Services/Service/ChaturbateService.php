<?php

namespace App\Services\Service;

use App\Models\Config;
use App\Repositories\Interfaces\ModelRepositoryInterface;
use App\Services\Interfaces\ChaturbateServiceInterface;
use App\Services\Interfaces\RequestApiServiceInterface;
use App\Services\Interfaces\ScripCashServiceInterface;

class ChaturbateService implements ChaturbateServiceInterface
{
    protected $modelRepository;
    protected $requestApiService;
    protected $api;

    public function __construct(
        ModelRepositoryInterface $modelRepository,
        RequestApiServiceInterface $requestApiService
    )
    {
        $this->modelRepository = $modelRepository;
        $this->requestApiService = $requestApiService;
    }

    protected function getConfig()
    {
        $config = Config::where('key', Config::CHATURBATE)->first();
        return $config;
    }

    // limit =1000
    public function performerOnlineList($param = [], $updateProfile = false, $config = null)
    {
        if (empty($param)) {
            $param = [
                'limit' => 50
            ];
        }
        if(empty($config)){
            $config = $this->getConfig();
        }
        $data = $this->requestApiService->getData($config, $param);
        $modelIds = [];
        foreach ($data as $item) {
            $modelIds [] = $item['username'];
            $exists = $this->modelRepository->getByColumn('model_id', $item['username']);
            if (empty($exists)) {
                $model = [
                    'model_id' => $item['username'],
                    'user_name' => $item['username'],
                    'display_name' => $item['display_name'],
                    'age' => $item['age'],
                    'gender' => $item['gender'],
                    'description' => $item['room_subject'],
                    'image' => $item['image_url'],
                    'iframe' => $item['iframe_embed'],
                    'link_embed' => null,
                    'link_snapshot' => $item['image_url'],
                    'chat_url' => $item['chat_room_url'],
                    'is_online' => true,
                    'source' => Config::CHATURBATE,
                    'json_data' => json_encode($item)
                ];
                $this->modelRepository->save($model);
            } else {
                if($updateProfile) {
                    $update = [
                        'user_name' => $item['username'],
                        'display_name' => $item['display_name'],
                        'age' => $item['age'],
                        'description' => $item['room_subject'],
                        'image' => $item['image_url'],
                        'iframe' => $item['iframe_embed'],
                        'link_snapshot' => $item['image_url'],
                        'chat_url' => $item['chat_room_url'],
                        'is_online' => true,
                        'source' => Config::CHATURBATE,
                        'json_data' => json_encode($item)
                    ];
                    $exists->update($update);
                }
            }
        }

        if(!empty($modelIds)) {
            // update offline
            $dataUpdateOffline = [
                'is_online' => 0
            ];
            $where = [
                'source' => Config::CHATURBATE
            ];
            $this->modelRepository->updateMany($dataUpdateOffline, $where, $modelIds, 'whereNotIn');

            // update online
            if(!$updateProfile) {
                $dataUpdateOnline = [
                    'is_online' => 0
                ];
                $where = [
                    'source' => Config::CHATURBATE
                ];
                $this->modelRepository->updateMany($dataUpdateOnline, $where, $modelIds);
            }
        }
    }
}
