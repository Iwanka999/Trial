<?php

namespace App\Services\Service;

use App\Models\Config;
use App\Models\Model;
use App\Repositories\Interfaces\CategoryRepositoryInterface;
use App\Repositories\Interfaces\ModelRepositoryInterface;
use App\Repositories\Interfaces\XLoveCashTagRepositoryInterface;
use App\Services\Interfaces\RequestApiServiceInterface;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Log;

class RequestApiService implements RequestApiServiceInterface
{
    protected $client;
    protected $modelRepository;
    protected $categoryRepository;
    protected $XLoveCashTagRepository;

    public function __construct(ModelRepositoryInterface $modelRepository,
                                CategoryRepositoryInterface $categoryRepository,
                                XLoveCashTagRepositoryInterface $XLoveCashTagRepository
    )
    {
        $this->client = new Client();
        $this->modelRepository = $modelRepository;
        $this->categoryRepository = $categoryRepository;
        $this->XLoveCashTagRepository = $XLoveCashTagRepository;
    }

    public function getData($api, $filter = [])
    {
        $data = (array)json_decode($api->data);
        $data = array_merge($data, $filter);
        $res = $this->client->request($api->method, $api->api_url, [
            Config::METHOD[strtoupper($api->method)] => $data
        ]);
        if ($res->getStatusCode() == 200) {
            $body = json_decode($res->getBody(), true);
            return $body;
        }
        return null;
    }

    public function updateOnlineData($data, $config)
    {
        switch ($config->key) {
            case Config::BONGA_CASH :
                $arrModelId = array_map(function ($x) {
                    return $x['username'];
                }, $data);
                break;
            case  Config::XLOVE_CASH :
                $data = $data['content']['models_list'];
                $arrModelId = array_map(function ($x) {
                    return $x['model_id'];
                }, $data);
                break;
            case Config::STRIP_CASH :
                $data = $data['models'];
                $arrModelId = array_map(function ($x) {
                    return $x['id'];
                }, $data);
                break;
            case Config::CHATURBATE :
                $arrModelId = array_map(function ($x) {
                    return $x['username'];
                }, $data);
                break;
        }
        if (!empty($arrModelId)) {
            Log::info('run update offline online from'.$config->key);
            $this->updateOffline($arrModelId, $config);
            $this->updateOnline($arrModelId, $config);
        }
    }

    public function updateCategory($data, $config)
    {
        $arrTags = [];
        switch ($config->key) {
            case Config::BONGA_CASH :
                foreach ($data as $item) {
                    $arrTags [$item['username']] = $item['tags'];
                }
                break;
            case  Config::XLOVE_CASH :
                $data = $data['content']['models_list'];
                foreach ($data as $item) {
                    $arrTags [$item['model_id']] = $item['tagList'];
                }
                break;
            case Config::STRIP_CASH :
                $data = $data['models'];
                foreach ($data as $item) {
                    $arrTags [$item['username']] = $item['tags'];
                }
                break;
            case Config::CHATURBATE :
                foreach ($data as $item) {
                    $arrTags [$item['username']] = $item['tags'];
                }
                break;
        }

        if (!empty($arrTags)) {

            $where = [
                'source' => $config->key
            ];
            // lấy ra tất cả những model vừa lấy đã tồn tại trong hệ thống
            // update các category của model đó
            $arrModelId = array_keys($arrTags);
            $existModels = $this->modelRepository->getMany($where,$arrModelId);
            foreach($existModels as $existModel){
                if($config->key === Config::XLOVE_CASH){
                    // update tags for XLoveCash
                    $categoryIds = $this->XLoveCashTagRepository->getByTags($arrTags[$existModel['model_id']]);
                    $existModel->categories()->sync($categoryIds);
                }else{
                    // update tags for bongacash ,chaturbate & stripcash
                    $categoryIds = $this->categoryRepository->getByTags($arrTags[$existModel['model_id']]);
                    $existModel->categories()->sync($categoryIds);
                }
            }
        }
    }

    public function saveData($data, $config)
    {
        $results = [];
        switch ($config->key) {
            case Config::BONGA_CASH :
                $dataConfig = (array)json_decode($config->data);
                $strChatUrl = "https://bngpt.com/promo.php?type=direct_link&v=2&c=$dataConfig[c]&amute=1&models[]=%s&model_offline=profile";
                foreach ($data as $item) {
                    $results [$item['username']] = [
                        'model_id' => $item['username'],
                        'user_name' => $item['username'],
                        'unique_user_name' => $item['username'],
                        'display_name' => $item['display_name'],
                        'age' => $item['display_age'],
                        'gender' => $item['gender'],
                        'description' => $item['turns_on'],
                        'image' => "https://" . str_replace('//', '', $item['profile_images']['profile_image']),
                        'iframe' => null,
                        'link_embed' => $item['embed_chat_url'],
                        'link_snapshot' => $item['profile_images']['thumbnail_image_big_live'],
//                        'chat_url' => $item['chat_url'],
                        'chat_url' => sprintf($strChatUrl, $item['username']),
                        'is_online' => true,
                        'source' => $config->key,
                        'json_data' => json_encode($item),
                    ];
                    $arrModelId[] = $item['username'];
                }
                break;
            case  Config::XLOVE_CASH :
                $data = $data['content']['models_list'];
                foreach ($data as $item) {
                    $results [$item['model_id']] = [
                        'model_id' => $item['model_id'],
                        'user_name' => $item['nick'],
                        'unique_user_name' => $item['nick'],
                        'display_name' => $item['nick'],
//                        'age' => null,
//                        'gender' => null,
                        'image' => "https://" . str_replace('http://', '',$item['model_profil_photo']),
                        'is_online' => $item['online'] ? true : false,
//                        'description' => null,
                        'iframe' => null,
                        'link_embed' => null,
                        'link_snapshot' => $item['camLive'],
                        'chat_url' => $item['model_link'],
                        'source' => $config->key,
                        'json_data' => json_encode($item),
                    ];
                    $arrModelId[] = $item['model_id'];
                }
                // update profile Xlove
                if (!empty($arrModelId)) {
                    $url = 'https://webservice-affiliate.xlovecam.com/model/getprofileinfo/';
                    $config->api_url = $url;

                    $chunk = 100;
                    $pages = ceil(count($arrModelId) / $chunk);
                    for ($i = 1; $i < ($pages + 1); $i++) {
                        $offset = (($i - 1) * $chunk);
                        $ids = array_slice($arrModelId, $offset, $chunk);
                        $param = [
                            'modelid' => $ids
                        ];
                        $modelInfos = $this->getData($config, $param)['content'];
                        foreach ($modelInfos as $modelId => $val) {
                            $results[$modelId] = array_merge($results[$modelId], [
                                'age' => $val['model']['age'],
                                'description' => $val['infoByLang']['description'],
                                'gender' => $val['model']['sex']
                            ]);
                        }
                    }
                }
                break;
            case Config::STRIP_CASH :
                $data = $data['models'];
                $configData = (array)json_decode($config->data);
                $url = "https://go.schjmpl.com/?userId= $configData[userId]&refreshRate=60&hasPlayer=true&hasLive=true&hasName=true&path=";
                foreach ($data as $item) {
                    $linkEmbed = "https://lite-iframe.stripcdn.com/" . $item['username'] . "?userId=" . $configData['userId'];
                    $chatUrl = "https://go.gldrdr.com/?userId=$configData[userId]&path=/cams/$item[username]";
                    $results [$item['id']] = [
                        'model_id' => $item['id'],
                        'user_name' => $item['username'],
                        'unique_user_name' => $item['username'],
                        'display_name' => $item['username'],
                        'age' => null,
                        'gender' => $item['gender'],
                        'description' => null,
                        'image' => $item['previewUrl'],
                        'iframe' => $url . $item['username'],
                        'link_embed' => $linkEmbed,
                        'link_snapshot' => $item['snapshotUrl'],
                        'chat_url' => $chatUrl,
                        'is_online' => true,
                        'source' => $config->key,
                        'json_data' => json_encode($item),
                    ];
                    $arrModelId[] = $item['id'];

                }
                break;
            case Config::CHATURBATE :
                foreach ($data as $key => $item) {
                    $results [$item['username']] = [
                        'model_id' => $item['username'],
                        'user_name' => $item['username'],
                        'unique_user_name' => $item['username'],
                        'display_name' => !empty($item['display_name']) && $item['display_name'] != '' ? $item['display_name'] : $item['username'],
                        'age' => $item['age'],
                        'gender' => $item['gender'],
                        'description' => $item['room_subject'],
                        'image' => $item['image_url'],
                        'iframe' => $item['iframe_embed'],
                        'link_embed' => null,
                        'link_snapshot' => $item['image_url'],
                        'chat_url' => $item['chat_room_url'],
                        'is_online' => true,
                        'source' => $config->key,
                        'json_data' => json_encode($item),
                    ];
                    $arrModelId[] = $item['username'];
                }
                break;
        }
        if (!empty($results)) {
            $where = [
                'source' => $config->key
            ];
            // lấy ra tất cả những model vừa lấy đã tồn tại trong hệ thống
            // update các model đó.
            // sau đó loại bỏ các model đó khỏi mảng các dữ liệu vừa lấy đc
            // sau đó mảng chỉ còn lại các phần tử mới => add many
            $existModels = $this->modelRepository->getMany($where,$arrModelId);
            foreach($existModels as $existModel){
                // nếu là data cữ thì k update lại cột unique
                unset($results[$existModel['model_id']]['unique_user_name']);
                unset($results[$existModel['model_id']]['source']);
                $existModel->update($results[$existModel['model_id']]);
                unset($results[$existModel['model_id']]);
            }

            if(!empty($results)){
                foreach($results as $key => $item){
                    $this->modelRepository->saveMany($item);
                }
            }

            $this->handleDuplicateUsername();

//            foreach ($results as $key => $val) {
//                $dataStore = $this->modelRepository->getByMultiColumn([
//                    'model_id' => $val['model_id'],
//                    'source' => $config->key
//                ]);
//                if (!empty($dataStore)) {
//                    $dataStore->update($val);
//                } else {
//                    $this->modelRepository->save($val);
//                }
//            }
//            $this->modelRepository->deleteByMultiColumn([
//                'source' => $config->key
//            ]);
//
//            $chunk = 200;
//            $pages = ceil(count($results) / $chunk);
//            for ($i = 1; $i < ($pages + 1); $i++) {
//                $offset = (($i - 1) * $chunk);
//                $data = array_slice($results, $offset, $chunk);
//                $this->modelRepository->saveMany($data);
//            }
        }
    }

    public function handleDuplicateUsername(){
        $duplicateData = $this->modelRepository->getDuplicateUsername();
        foreach($duplicateData as $dup){
            $data = $this->modelRepository->getListByColumn('unique_user_name',$dup['unique_user_name']);
            foreach($data as $key => $model){
                if($key != 0) {
                    $model->unique_user_name = $model->unique_user_name . "_" . $key;
                    $model->save();
                }
            }
        }
    }

    protected function updateOnline($arrModelId, $config)
    {
        //update online
        $dataUpdateOffline = [
            'is_online' => 1
        ];
        $where = [
            'source' => $config->key
        ];
        $this->modelRepository->updateMany($dataUpdateOffline, $where, $arrModelId);
    }

    protected function updateOffline($arrModelId, $config)
    {
        //update offline
        $dataUpdateOffline = [
            'is_online' => 0
        ];
        $where = [
            'source' => $config->key
        ];
        $this->modelRepository->updateMany($dataUpdateOffline, $where, $arrModelId, 'whereNotIn');
    }

    protected function handleGender($gender)
    {

        if (in_array($gender, Config::STRIP_CASH_SEX['trans'])) {
            return 'trans';
        }
        if (in_array($gender, Config::STRIP_CASH_SEX['male'])) {
            return 'male';
        }
        if (in_array($gender, Config::STRIP_CASH_SEX['female'])) {
            return 'male';
        }
        return $gender;
    }

}
