<?php

namespace App\Services\Service;

use App\Models\Config;
use App\Repositories\Interfaces\ModelRepositoryInterface;
use App\Services\Interfaces\RequestApiServiceInterface;
use App\Services\Interfaces\ScripCashServiceInterface;

class ScripCashService implements ScripCashServiceInterface
{
    protected $modelRepository;
    protected $requestApiService;
    protected $api;

    public function __construct(
        ModelRepositoryInterface $modelRepository,
        RequestApiServiceInterface $requestApiService
    )
    {
        $this->modelRepository = $modelRepository;
        $this->requestApiService = $requestApiService;
    }

    protected function getConfig()
    {
        $config = Config::where('key', Config::STRIP_CASH)->first();
        return $config;
    }

    // limit =1000
    public function performerOnlineList($param = [], $updateProfile = false, $config = null)
    {
        if (empty($param)) {
            $param = [
                'limit' => 50
            ];
        }
        if(empty($config)){
            $config = $this->getConfig();
        }
        $data = $this->requestApiService->getData($config, $param);

        $data = $data['models'];
        $url = "https://go.schjmp.com/?userId=106150bfbb9ac378aac92fb495c8ed29229e11b849b66525428d363cec90b9fd&refreshRate=60&hasPlayer=true&hasLive=true&hasName=true&path=";

        $modelIds = [];
        foreach ($data as $item) {
            $modelIds [] = $item['id'];
            $exists = $this->modelRepository->getByColumn('model_id', $item['id']);
            if (empty($exists)) {
                $model = [
                    'model_id' => $item['id'],
                    'user_name' => $item['username'],
                    'display_name' => $item['username'],
                    'age' => null,
                    'gender' => $item['gender'],
                    'description' => null,
                    'image' => $item['previewUrl'],
                    'iframe' => $url . $item['username'],
                    'link_embed' => null,
                    'link_snapshot' => $item['snapshotUrl'],
                    'chat_url' => $url . $item['username'],
                    'is_online' => true,
                    'source' => Config::STRIP_CASH,
                    'json_data' => json_encode($item)
                ];
                $this->modelRepository->save($model);
            } else {
                if($updateProfile) {
                    $update = [
                        'user_name' => $item['username'],
                        'display_name' => $item['username'],
                        'gender' => $item['gender'],
                        'image' => $item['previewUrl'],
                        'iframe' => $url . $item['username'],
                        'link_embed' => null,
                        'link_snapshot' => $item['snapshotUrl'],
                        'chat_url' => $url . $item['username'],
                        'is_online' => true,
                        'json_data' => json_encode($item)
                    ];
                    $exists->update($update);
                }
            }
        }

        if(!empty($modelIds)) {
            // update offline
            $dataUpdateOffline = [
                'is_online' => 0
            ];
            $where = [
                'source' => Config::STRIP_CASH
            ];
            $this->modelRepository->updateMany($dataUpdateOffline, $where, $modelIds, 'whereNotIn');

            // update online
            if(!$updateProfile) {
                $dataUpdateOnline = [
                    'is_online' => 0
                ];
                $where = [
                    'source' => Config::STRIP_CASH
                ];
                $this->modelRepository->updateMany($dataUpdateOnline, $where, $modelIds);
            }
        }
    }
}
