<?php

namespace App\Services\Service;

use App\Models\Config;
use App\Repositories\Interfaces\ModelRepositoryInterface;
use App\Services\Interfaces\XLoveCamServiceInterface;
use App\Utils\XLoveApiCurl;

class XLoveCamService implements XLoveCamServiceInterface
{
    protected $modelRepository;
    protected $api;

    public function __construct(
        ModelRepositoryInterface $modelRepository
    )
    {
        $config = $this->getConfig();
        $this->api = new XLoveApiCurl($config);
        $this->modelRepository = $modelRepository;
    }

    protected function getConfig(){
        $config = Config::where('key' ,'xlovecash')->first();
        $data = (array)json_decode($config->data);
        return  array(
            // Change this value with your affiliate id (keep it as string even if it's a number)
            'affiliateId' => $data["authItemId"],
            // Change this value too with the one provider in the promotool page
            'secretKey' => $data["authSecret"],
        );
    }

    // limit =1000
    public function performerOnlineList($param = [], $performerCheckIsOnline = false, $performerProfileInfo = false){
        if(empty($param)){
            $param = [
                'limit' => 1000
            ];
        }
        $data =  $this->api->performerOnlineList($param);
        $data = $data['models_list'];
        $arrModelId = [];
        foreach($data as $item){
            if(empty($this->modelRepository->getByColumn('model_id',$item['model_id']))){
                $model = [
                    'model_id' => $item['model_id'],
                    'user_name' => $item['nick'],
                    'display_name' => $item['nick'],
                    'age' => null,
                    'gender' => null,
                    'image' => $item['model_profil_photo'],
                    'is_online' => $item['online'] ? true : false,
                    'description' => null,
                    'iframe' => null,
                    'link_embed' => null,
                    'link_snapshot' => $item['camLive'],
                    'chat_url' =>  null,
                    'source' =>  Config::XLOVE_CASH,
                    'json_data' => json_encode($item)
                ];
                $this->modelRepository->save($model);
            }
            $arrModelId[] = $item['model_id'];
        }
        if(!empty($arrModelId)){
            $chunk = 100;
            $pages = ceil(count($arrModelId) / $chunk);
            for ($i = 1; $i < ($pages + 1); $i++) {
                $offset = (($i - 1)  * $chunk);
                $ids = array_slice($arrModelId, $offset, $chunk);
                if($performerCheckIsOnline){
                    $this->performerCheckIsOnline($ids);
                }
                if($performerProfileInfo){
                    $this->performerProfileInfo($ids);
                }
            }
        }
    }

    public function performerCheckIsOnline(array $modelIds){
        $data =  $this->api->performerCheckIsOnline($modelIds);
        $arrOnline =array_filter($data,function ($val){
            return $val['isOnline'] == 1;
        });
        $arrIds =array_keys($arrOnline);
        // update online
        $this->modelRepository->updateMany([
            'is_online' => 1
        ],[
            'source' => Config::XLOVE_CASH,
        ],$arrIds);

        //update offline
        $this->modelRepository->updateMany([
            'is_online' => 0
        ],[
            'source' => Config::XLOVE_CASH,
        ],$arrIds,'whereNotIn');


    }
    public function performerProfileInfo(array $modelIds){
        $data =  $this->api->performerProfileInfo($modelIds);
        // update online
        foreach($data as $modelId => $val){
            $this->modelRepository->updateByModelId([
                'age' => $val['model']['age'],
                'description' => $val['infoByLang']['description'],
                'gender' => $val['model']['sex']
            ],$modelId);
        }
    }

}
