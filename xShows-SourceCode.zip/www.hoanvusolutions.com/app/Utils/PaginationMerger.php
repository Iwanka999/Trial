<?php
/**
 * Created by PhpStorm.
 * User: huynh
 * Date: 16-Aug-20
 * Time: 1:41 PM
 */

namespace App\Utils;

use Illuminate\Pagination\LengthAwarePaginator;

class PaginationMerger
{
    static public function merge(LengthAwarePaginator $collection1, LengthAwarePaginator $collection2)
    {
        $total = $collection1->total() + $collection2->total();
//        var_dump($collection1->total() );
//        var_dump($collection2->total() );

        $perPage = $collection1->perPage() + $collection2->perPage();

//        dump($collection1->perPage() . ' + ' . $collection2->perPage());

        $items = array_merge($collection1->items(), $collection2->items());
        $paginator = new LengthAwarePaginator($items, $total, $perPage);

        return $paginator;
    }
}
