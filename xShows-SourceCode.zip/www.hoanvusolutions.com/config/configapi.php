<?php

return [
    // Change this value with your affiliate id (keep it as string even if it's a number)
    'affiliateId' => '18856',

    // Change this value too with the one provider in the promotool page
    'secretKey'   => '63389fc7199e9f7bf6c7ac63057cec86',
];
