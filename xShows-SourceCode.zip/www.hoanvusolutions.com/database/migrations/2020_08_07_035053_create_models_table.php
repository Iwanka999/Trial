<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateModelsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('models', function (Blueprint $table) {
            $table->id();
            $table->string('model_id',50);
            $table->string('user_name',50);
            $table->string('display_name');
            $table->boolean('is_online')->default(true);
            $table->integer('age')->nullable();
            $table->string('gender',40)->nullable();
            $table->text('description')->nullable();
            $table->string('image');
            $table->text('iframe')->nullable();
            $table->text('link_embed')->nullable();
            $table->text('link_snapshot')->nullable();
            $table->text('chat_url')->nullable();
            $table->string('source',12);
            $table->json('json_data');
            //stripScore
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('Models');
    }
}
