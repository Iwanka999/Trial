<?php

use Illuminate\Database\Seeder;

class ConfigSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\Models\Config::insert([
            [
                'key' => 'bongacash',
                'is_active' => 1,
                'method' => 'GET',
                'api_url' => 'https://bngpt.com/promo.php',
                'data' => '{"c":"694510","type":"api","api_v":1,"api_type":"json"}'
            ],
            [
                'key' => 'xlovecash',
                'is_active' => 1,
                'method' => 'POST',
                'api_url' => 'https://webservice-affiliate.xlovecam.com/model/listonline',
                'data' => '{"authServiceId":2,"authItemId": 18856,"authSecret":"63389fc7199e9f7bf6c7ac63057cec86","api" : "filterList","lang": "en"}'
            ],
            [
                'key' => 'chaturbate',
                'is_active' => 1,
                'method' => 'GET',
                'api_url' => 'https://chaturbate.com/affiliates/api/onlinerooms',
                'data' => '{"wm": "ZCn7T", "tour": "NxHf", "format": "json"}'
            ],
            [
                'key' => 'stripcash',
                'is_active' => 1,
                'method' => 'GET',
                'api_url' => 'https://stripchat.com/api/external/v4/widget',
                'data' => '{"userId": "106150bfbb9ac378aac92fb495c8ed29229e11b849b66525428d363cec90b9fd"}'
            ],
        ]);
    }
}
