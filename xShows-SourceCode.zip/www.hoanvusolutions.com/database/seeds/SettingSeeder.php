<?php

use Illuminate\Database\Seeder;

class SettingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\Models\Setting::insert([
            [
                'key' => 'title',
                'value' => 'XShows'
            ],
            [
                'key' => 'google_analytics_code',
                'value' => 'UA-176272301-1'
            ],
            [
                'key' => 'logo',
                'value' => 'images/logo.png'
            ],[
                'key' => 'meta_description',
                'value' => 'description xshows'
            ],[
                'key' => 'meta_keywords',
                'value' => 'Xshows'
            ],
        ]);
    }
}
