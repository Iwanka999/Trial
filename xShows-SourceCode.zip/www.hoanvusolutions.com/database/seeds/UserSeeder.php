<?php

use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \Illuminate\Support\Facades\DB::table('users')->insert([
            [
                'name' => 'Administrator',
                'email' => 'adminadmin@gmail.com',
                'password' => \Illuminate\Support\Facades\Hash::make('123456'),
                'role' => "admin"
            ],
            [
                'name' => 'Administrator 2',
                'email' => 'adminadmin2@gmail.com',
                'password' => \Illuminate\Support\Facades\Hash::make('123456'),
                'role' => "admin"
            ],
        ]);
    }
}
