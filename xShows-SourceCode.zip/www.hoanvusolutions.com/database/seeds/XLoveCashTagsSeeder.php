<?php

use Illuminate\Database\Seeder;

class XLoveCashTagsSeeder extends Seeder
{

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\Models\XLoveCashTags::insert([
            [
                "category_id" => 1,
                "value" => 1,
                "title" => "69"
            ],
            [
                "category_id" => 2,
                "value" => 2,
                "title" => "Anal Sex"
            ],
            [
                "category_id" => 3,
                "value" => 3,
                "title" => "Closeup"
            ],
            [
                "category_id" => 4,
                "value" => 4,
                "title" => "Sex Toys"
            ],
            [
                "category_id" => 5,
                "value" => 6,
                "title" => "Femdom"
            ],
            [
                "category_id" => 6,
                "value" => 7,
                "title" => "Fetish Female"
            ],
            [
                "category_id" => null,
                "value" => 8,
                "title" => "Gymnast"
            ],
            [
                "category_id" => null,
                "value" => 9,
                "title" => "Heels"
            ],
            [
                "category_id" => 7,
                "value" => 10,
                "title" => "Hairy"
            ],
            [
                "category_id" => 8,
                "value" => 11,
                "title" => "Latex"
            ],
            [
                "category_id" => 9,
                "value" => 12,
                "title" => "Leather"
            ],
            [
                "category_id" => 10,
                "value" => 13,
                "title" => "Live Orgasm"
            ],
            [
                "category_id" => 11,
                "value" => 14,
                "title" => "Love Balls"
            ],
            [
                "category_id" => 12,
                "value" => 15,
                "title" => "Massage"
            ],
            [
                "category_id" => 13,
                "value" => 16,
                "title" => "Masturbation"
            ],
            [
                "category_id" => 14,
                "value" => 17,
                "title" => "Moaning"
            ],
            [
                "category_id" => 15,
                "value" => 18,
                "title" => "Nurse"
            ],
            [
                "category_id" => 16,
                "value" => 19,
                "title" => "Nylon"
            ],
            [
                "category_id" => 17,
                "value" => 20,
                "title" => "Oil"
            ],
            [
                "category_id" => 18,
                "value" => 21,
                "title" => "Oral"
            ],
            [
                "category_id" => 19,
                "value" => 22,
                "title" => "Panties"
            ],
            [
                "category_id" => 20,
                "value" => 23,
                "title" => "Pantyhose"
            ],
            [
                "category_id" => 21,
                "value" => 25,
                "title" => "Piercings"
            ],
            [
                "category_id" => 22,
                "value" => 26,
                "title" => "Pornstar"
            ],
            [
                "category_id" => 23,
                "value" => 27,
                "title" => "Secretary"
            ],
            [
                "category_id" => 24,
                "value" => 28,
                "title" => "Shower"
            ],
            [
                "category_id" => 25,
                "value" => 29,
                "title" => "Buttplug"
            ],
            [
                "category_id" => 26,
                "value" => 30,
                "title" => "Cougar - MILF"
            ],
            [
                "category_id" => 27,
                "value" => 31,
                "title" => "Foot"
            ],
            [
                "category_id" => 28,
                "value" => 32,
                "title" => "Spanking"
            ],
            [
                "category_id" => 29,
                "value" => 33,
                "title" => "Squirting"
            ],
            [
                "category_id" => 30,
                "value" => 34,
                "title" => "Stockings"
            ],
            [
                "category_id" => 31,
                "value" => 35,
                "title" => "Submissive"
            ],
            [
                "category_id" => 32,
                "value" => 36,
                "title" => "Tattoo"
            ],
            [
                "category_id" =>33,
                "value" => 37,
                "title" => "Uniform"
            ],
            [
                "category_id" => 34,
                "value" => 38,
                "title" => "Vibrator"
            ],
            [
                "category_id" => 35,
                "value" => 39,
                "title" => "Zoom Cam"
            ],
            [
                "category_id" => null,
                "value" => 40,
                "title" => "Sound Chat"
            ],
            [
                "category_id" => 85,
                "value" => 41,
                "title" => "Anilingus"
            ],
            [
                "category_id" => 37,
                "value" => 42,
                "title" => "Armpits"
            ],
            [
                "category_id" => 38,
                "value" => 43,
                "title" => "Big Penis"
            ],
            [
                "category_id" => 39,
                "value" => 44,
                "title" => "Boots"
            ],
            [
                "category_id" => 40,
                "value" => 46,
                "title" => "Exhibitionism"
            ],
            [
                "category_id" => 41,
                "value" => 47,
                "title" => "Fur"
            ],
            [
                "category_id" => null,
                "value" => 48,
                "title" => "Hair Colour"
            ],
            [
                "category_id" => null,
                "value" => 49,
                "title" => "Hairy Men"
            ],
            [
                "category_id" => 42,
                "value" => 51,
                "title" => "Legs"
            ],
            [
                "category_id" => 43,
                "value" => 52,
                "title" => "Muscles"
            ],
            [
                "category_id" => 44,
                "value" => 53,
                "title" => "Older Men"
            ],
            [
                "category_id" => 45,
                "value" => 54,
                "title" => "Rubber"
            ],
            [
                "category_id" => 46,
                "value" => 55,
                "title" => "Shoes"
            ],
            [
                "category_id" => 47,
                "value" => 56,
                "title" => "Small Penis"
            ],
            [
                "category_id" => 48,
                "value" => 57,
                "title" => "Tickling"
            ],
            [
                "category_id" => 49,
                "value" => 58,
                "title" => "Transvestism"
            ],
            [
                "category_id" => 50,
                "value" => 59,
                "title" => "Underwear"
            ],
            [
                "category_id" => 51,
                "value" => 60,
                "title" => "Voyeurism"
            ],
            [
                "category_id" => 52,
                "value" => 61,
                "title" => "Cunnilingus"
            ],
            [
                "category_id" => 29,
                "value" => 62,
                "title" => "Squirting"
            ],
            [
                "category_id" => 64,
                "value" => 63,
                "title" => "Strap-on dildo"
            ]
        ]);
    }
}
