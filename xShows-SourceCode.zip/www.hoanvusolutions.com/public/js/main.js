$(document).ready(function () {

$( ".toogle-a" ).click(function() {
  $( ".right-header" ).toggleClass('show');
  $(this).toggleClass('active');
})
$( ".category-m" ).click(function() {
  $( ".menu-left" ).toggleClass('show');
  $( ".bg-cate" ).toggleClass('show');
  $(this).toggleClass('active');
  $("body, html").toggleClass('hide');
})
$( ".bg-cate" ).click(function() {
  $( ".menu-left" ).removeClass('show');
  $( ".bg-cate" ).removeClass('show');
  $( ".category-m" ).removeClass('active');
  $("body, html").removeClass('hide');
})
var msnry = new Masonry( '.grid', {
  icolumnWidth: '.grid-sizer',
  itemSelector: '.grid-item',
  percentPosition: true
});

    var rightHeight = $('.main-content .grid').height();
    $('.menu-left ul').height(rightHeight + 135);
});

$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

$('body').on('click', 'div.favourite', function (e) {
    e.preventDefault();
    var element = $(this);
    var url = $(this).data('url');
    $.ajax({
        type: "POST",
        url: url,
        dataType: 'json',
        success: function (result) {
            if(element.find(".fav-model").hasClass('active')){
                element.find(".fav-model").removeClass('active');
            }else{
                element.find(".fav-model").addClass('active');
            }

            if(element.find(".detail-favorites").hasClass('active')){
                element.find(".detail-favorites").removeClass('active');
            }else{
                element.find(".detail-favorites").addClass('active');
            }

            alertify.success(result.msg);
        },error: function (errors) {
            var response = errors.responseJSON;
            if(response.errors == null){
                alertify.error(response.msg);
            }
        }
    });
});

function updateData(href, method,valueForm, message, modal = 'div#myModal', form ='form#data-form' ) {
    $.ajax({
        type: method,
        url: href,
        data: valueForm,
        dataType: 'json',
        success: function (result) {
            alertify.success(result.message);
            oTable.draw();
        },error: function (errors) {
            var response = errors.responseJSON;
            if(response.errors == null){
                alertify.error(response.msg);
            }
        }
    });
}
