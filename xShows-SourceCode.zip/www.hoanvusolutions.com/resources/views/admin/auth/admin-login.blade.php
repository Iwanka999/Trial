<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('app.name') }}</title>


    <link href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,400;0,700;1,400;1,700&display=swap"
          rel="stylesheet">
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="{{asset('/css/bootstrap.css') }}">
    <link rel="stylesheet" href="{{asset('/font-awesome/css/all.css') }}">

    <!-- Custom styles for this template -->
    <link rel="stylesheet" href="{{asset('/css/style.css') }}">
    <link rel="stylesheet" href="{{asset('/css/responsive.css') }}">

    <link href="{{asset('alertify/css/alertify.min.css')}}" id='aleritify_ds' rel="stylesheet">
    <link href="{{asset('alertify/css/themes/bootstrap.min.css')}}" id='aleritify_s' rel="stylesheet">
    <!-- Javascript -->

<body>

<div class="content-inner login-main">
    <div class="login-box">
        <h2>Login</h2>
        <form method="POST" action="{{ route('admin.login') }}">
            @csrf
            <div class="form-group">
                <label>{{ __('E-Mail Address') }}</label>
                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror"
                       name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>
                @error('email')
                <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
            <div class="form-group">
                <label>{{ __('Password') }}</label>
                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror"
                       name="password" required autocomplete="current-password">
                @error('password')
                <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                @enderror
            </div>
            <div class="form-group">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="remember"
                           id="remember" {{ old('remember') ? 'checked' : '' }}>
                    <label class="form-check-label" for="remember">
                        {{ __('Keep me logged in') }}
                    </label>
                </div>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-danger btn-block btn-lg">{{ __('Login') }}</button>
            </div>
            <div class="text-center">
                <a class="btn btn-link" href="{{ route('password.request') }}">
                    {{ __('Forgot Your Password?') }}
                </a>
            </div>
        </form>
    </div>

</div>

<footer>
    <div class="copyright">2020 - Xshow. All rights reserved.</div>
</footer>

<meta name="csrf-token" content="{{ csrf_token() }}">
<script src="{{asset('/js/jquery.min.js')}}" type="text/javascript"></script>

<script src="{{asset('/js/masonry.min.js')}}"></script>
<script src="{{asset('/js/main.js')}}"></script>
<script src="{{asset('/alertify/alertify.min.js')}}" type="text/javascript"></script>

@stack('scripts')
</body>
</html>
