<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Đăng nhập hệ thống</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="{{ asset('static/vendor/fontawesome/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset('static/vendor/adminlte/css/adminlte.min.css') }}">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    <style>
        .error {
            margin: 0;
            font-size: 0.75rem;
            color: var(--red);
        }

        .fail {
            font-size: 1rem;
            color: var(--red);
            margin-top: 1rem;

        }
    </style>
</head>
<body class="hold-transition login-page">
<div class="login-box">
    <div class="card">
        <div class="card-body login-card-body">
            <p class="login-box-msg">Đăng nhập hệ thống</p>
            <form action="{{ route('login') }}" method="post" accept-charset="utf-8">
                @csrf
                @error('username')
                    <label for="email" class="error">
                        {{ $message }}
                    </label>
                @enderror
                <div class="input-group mb-3">
                    <input type="email" name="email" id="email" class="form-control" placeholder="Email" value="{{ old('email', '') }}">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-user"></span>
                        </div>
                    </div>
                </div>
                @error('password')
                    <label for="password" class="error">
                        {{ $message }}
                    </label>
                @enderror
                <div class="input-group mb-3">
                    <input type="password" name="password" id="password" class="form-control" placeholder="Password">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-lock"></span>
                        </div>
                    </div>
                </div>
                <div class="input-group mb-3">
                    <input type="checkbox" name="password" id="password" class="form-check-input form-control" >
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-lock"></span>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary btn-block">Đăng nhập</button>
                    </div>
                </div>
                @if (session('loginFail'))
                    <div class="row">
                        <div class="col-12"><p class="text-center fail">{{ session('loginFail') }}</p></div>
                    </div>
                @endif
            </form>
            <p class="mb-1">
                <a href="#">I forgot my password</a>
            </p>
        </div>
    </div>
</div>
</body>
</html>
