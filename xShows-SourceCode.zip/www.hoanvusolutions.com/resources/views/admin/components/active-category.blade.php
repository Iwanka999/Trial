<input type="checkbox" class="active-item  checkbox-text-zoom-size"
       {{ $model->is_active ? 'checked' : '' }}
       data-id="{{ $model->id }}"
       data-link="{{ $link }}"
       >
