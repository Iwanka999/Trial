<footer class="main-footer">
    <strong>Copyright &copy; 2020.</strong>
    All rights reserved.
</footer>
