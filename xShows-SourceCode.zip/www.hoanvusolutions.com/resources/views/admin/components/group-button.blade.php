<div class="btn-group">
    <button type="button" class="btn btn-link dropdown-toggle"
            data-toggle="dropdown" aria-haspopup="true"
            aria-expanded="false"><i class="fas fa-ellipsis-h"></i></button>
    <div class="dropdown-menu dropdown-menu-right">
        @isset($edit)
            <a data-update="{{ $edit['update'] }}" data-get="{{ $edit['get'] }}" class="dropdown-item editUser">Edit</a>
        @endisset
        @isset($editMetaTag)
            <a data-href-update="{{ $editMetaTag['update'] }}" data-href-get="{{ $editMetaTag['get'] }}" class="dropdown-item show_data">Update Meta Tag</a>
        @endisset
        @isset($changePassword)
            <a data-update="{{$changePassword}}" class="dropdown-item changePassword">Change Password</a>
        @endisset
        @isset($delete)
            @if(!$model->trashed())
            <a data-link="{{$delete}}" class="dropdown-item delete_data">Delete</a>
            @endif
        @endisset
        @isset($restore)
            @if($model->trashed())
            <a data-link="{{$restore}}" class="dropdown-item restore_data">Restore</a>
            @endif
        @endisset
    </div>
</div>
