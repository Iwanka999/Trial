<nav class="main-header navbar navbar-expand navbar-light navbar-white">
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
    </ul>
    <ul class="navbar-nav ml-auto">
    <!-- Notifications Dropdown Menu -->
        <li class="nav-item dropdown">
            <a class="nav-link" data-toggle="dropdown" href="#">
                <i class="far fa-user"></i>
            </a>
            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                <span class="dropdown-item dropdown-header">{{ Auth::user()->name }}</span>
                <div class="dropdown-divider"></div>
                <span class="dropdown-item dropdown-header editAdmin">Update Profile</span>
{{--                <span class="dropdown-item dropdown-header changePasswordAdmin" data-update="{{ route('admins.changePasswordAdmin') }}">Change Password</span>--}}

                {{--                <a href="{{ isAdmin(Auth::user()) ? route('backend.info') : route('backend.shop.info') }}" class="dropdown-item">--}}
{{--                    <i class="fas fa-info mr-2"></i> Thông tin--}}
{{--                </a>--}}
                <div class="dropdown-divider"></div>
{{--                <a href="{{ isAdmin(Auth::user()) ? route('backend.info.change-password') : route('backend.shop.info.change-password') }}" class="dropdown-item">--}}
{{--                    <i class="fas fa-sync-alt mr-2"></i> Đổi mật khẩu--}}
{{--                </a>--}}
                <div class="dropdown-divider"></div>
                <a href="{{ route('logout') }}" class="dropdown-item dropdown-footer">Logout</a>
            </div>
        </li>
    </ul>
</nav>
@include('admin.modals.updateAdmin')
{{--@include('admin.modals.changePasswordAdmin')--}}
