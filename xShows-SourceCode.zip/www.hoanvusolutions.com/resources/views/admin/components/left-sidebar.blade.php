<aside class="main-sidebar elevation-4 sidebar-light-primary">
    <a href="{{ route('admin.home') }}" class="brand-link">
        <img src='{{ asset($logo_global) }}'>
{{--        <span class="brand-text font-weight-light">Manage</span>--}}
    </a>
    <div class="sidebar">
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img src="{{ asset('static/imgs/user.png') }}" class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info">
                <a href="#" class="d-block">
                    {{ Auth::user()->name }}
                </a>
            </div>
        </div>
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column nav-child-indent" data-widget="treeview" role="menu" data-accordion="false">
                <li class="nav-item">
                    <a href="{{ route('admin.home') }}" class="nav-link {{ active_menu('admin.home') }}">
                        <i class="nav-icon fas fa-home"></i>
                        <p>API</p>
                    </a>
                    <a href="{{ route('users.index') }}" class="nav-link  {{ active_menu('users.index') }}">
                        <i class="nav-icon fas fa-user"></i>
                        <p>User</p>
                    </a>
                    <a href="{{ route('settings.edit') }}" class="nav-link  {{ active_menu('settings.edit') }}">
                        <i class="nav-icon fas fa-cogs"></i>
                        <p>Setting</p>
                    </a>
                    <a href="{{ route('categories.index') }}" class="nav-link  {{ active_menu('categories.index') }}">
                        <i class="nav-icon fa fa-list-alt"></i>
                        <p>Category</p>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</aside>
