@extends('admin.layouts.master-admin')
@section('title', 'Manage api')
@section('content')
    @include('admin.components.content-header', ['title' => 'API'])
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <form action="" method="get" id="form-filter">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">List</h3>
{{--                                <div class="card-tools">--}}
{{--                                    <button type="submit" class="btn btn-primary">Search</button>--}}
{{--                                    <a href="#" class="btn btn-default">Refresh</a>--}}
{{--                                </div>--}}
                            </div>
                            <div class="card-body table-responsive p-0" style="max-height: 740px">
                                <table class="table table-head-fixed text-nowrap">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>API</th>
                                        <th>Status</th>
{{--                                        <th>Action</th>--}}
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @if (isset($configs) && $configs->count())
                                        @foreach ($configs as $index => $item)
                                            <tr>
                                                <td>{{ $item->id }}</td>
                                                <td> {{ $item->key }}</td>
                                                <td>
                                                    <input type="checkbox" class="active-item checkbox-text-zoom-size"
                                                           {{ $item->is_active ? 'checked' : '' }}
                                                           data-on-color="success"
                                                           data-id="{{ $item->id }}"
                                                           data-link="{{ route('config.updates-status',$item->id) }}"
                                                           data-size="small">
                                                </td>
{{--                                                <td>--}}
{{--                                                    <div class="btn-group">--}}
{{--                                                        <button type="button" class="btn btn-link dropdown-toggle"--}}
{{--                                                                data-toggle="dropdown" aria-haspopup="true"--}}
{{--                                                                aria-expanded="false"><i class="fas fa-ellipsis-h"></i>--}}
{{--                                                        </button>--}}
{{--                                                        <div class="dropdown-menu dropdown-menu-right">--}}
{{--                                                            <a href="#" data-id="{{ $item->id }}"--}}
{{--                                                               data-source="{{ $item->key }}"--}}
{{--                                                               data-get="{{ route('config.edit',$item->id) }}"--}}
{{--                                                               data-update="{{ route('config.update',$item->id) }}"--}}
{{--                                                               class="dropdown-item edit-data">Edit</a>--}}
{{--                                                        </div>--}}
{{--                                                    </div>--}}
{{--                                                </td>--}}
                                            </tr>
                                        @endforeach
                                    @else
                                        <tr>
                                            <td colspan="4" class="text-center">Không tìm thấy dữ liệu</td>
                                        </tr>
                                    @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    @foreach ($configs as $index => $item)
        @include('admin.modals.'.$item->key)
    @endforeach

@endsection
@section('script')
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
    <script src="{{ asset('static/backend/js/config.js?v='.time()) }}"></script>
@endsection
