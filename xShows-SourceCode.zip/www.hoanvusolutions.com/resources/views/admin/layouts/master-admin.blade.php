<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title')</title>
    <!-- Fontawesome 5 -->
    <link rel="stylesheet" href="{{ asset('static/vendor/fontawesome/css/all.min.css') }}">
    <!-- Select2 -->
    <link href="{{ asset('static/vendor/select2/css/select2.min.css') }}" rel="stylesheet" />
    <link href="{{ asset('static/vendor/select2/css/select2-bootstrap4.min.css') }}" rel="stylesheet" />
    <!-- Jquery ui (datepicker) -->
    <link rel="stylesheet" href="{{ asset('static/backend/css/custom.css?v='.time()) }}">
    <link rel="stylesheet" href="{{ asset('static/vendor/jquery-ui/jquery-ui.min.css') }}">
    <link rel="stylesheet" href="{{ asset('static/vendor/jquery-ui/jquery-ui.theme.min.css') }}">
    <!-- iCheck for checkboxes and radio inputs -->
    <link rel="stylesheet" href="{{ asset('static/vendor/icheck-bootstrap/icheck-bootstrap.min.css') }}">
    <!-- Tempusdominus Bbootstrap 4 -->
    <link rel="stylesheet" href="{{ asset('static/vendor/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css') }}">
    <!-- Bootstrap switch -->
    <link rel="stylesheet" href="{{ asset('static/vendor/bootstrap-switch/css/bootstrap4/bootstrap-switch.min.css') }}">
    <!-- Admin LTE -->
    <link rel="stylesheet" href="{{ asset('static/vendor/adminlte/css/adminlte.min.css') }}">

    <link rel="stylesheet" href="{{asset('datatables/jquery.dataTables.min.css') }}">

    <link href="{{asset('alertify/css/alertify.min.css')}}" id='aleritify_ds' rel="stylesheet">
    <link href="{{asset('alertify/css/themes/bootstrap.min.css')}}" id='aleritify_s' rel="stylesheet">

    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

    @yield('style')
</head>
<body class="sidebar-mini layout-fixed text-sm" style="height: auto">
    <div class="wrapper">
        @include('admin.components.header')
        @include('admin.components.left-sidebar')
        <div class="content-wrapper">
            @yield('content')
        </div>
        @include('admin.components.footer')
    </div>
    <div id="pn-loading">
        <div class="fa-3x">
            <i class="fas fa-circle-notch fa-spin"></i>
        </div>
    </div>

    <!-- Core -->
    <script src="{{ asset('static/vendor/jquery/jquery.min.js') }}"></script>
    <script src="{{ asset('static/vendor/jquery-ui/jquery-ui.min.js') }}"></script>
    <script src="{{ asset('static/vendor/moment/moment.min.js') }}"></script>
    <script src="{{ asset('static/vendor/moment/locale/vi.js') }}"></script>
    <script src="{{ asset('static/vendor/jquery-validation-plugin/jquery.validate.min.js') }}"></script>
    <script src="{{ asset('static/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
    <script src="{{ asset('static/vendor/sweetalert2/sweetalert2.all.min.js') }}"></script>
    <script src="{{ asset('static/vendor/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js') }}"></script>
    <script src="{{ asset('static/vendor/bootstrap-switch/js/bootstrap-switch.min.js') }}"></script>
    <script src="{{ asset('static/vendor/daterangepicker/daterangepicker.js') }}"></script>
    <script src="{{ asset('static/vendor/summernote/summernote-bs4.min.js') }}"></script>
    <script src="{{ asset('static/vendor/select2/js/select2.full.min.js') }}"></script>
    <script src="{{asset('alertify/alertify.min.js')}}" type="text/javascript"></script>

    <!-- Admin LTE -->
    <script src="{{ asset('static/vendor/adminlte/js/adminlte.min.js') }}"></script>

    <script type="text/javascript" charset="utf-8">
        // $.ajaxSetup({
        //     headers: {
        //         'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        //     }
        // });
    </script>
    <script src="{{ asset('static/backend/js/custom.js') }}"></script>
    <script src="{{ asset('static/backend/js/admin.js') }}"></script>
    @yield('script')
</body>
</html>
