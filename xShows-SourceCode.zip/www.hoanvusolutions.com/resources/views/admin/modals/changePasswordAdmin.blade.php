<div class="modal fade" id="modalChangePasswordAdmin" role="dialog">
    <div class="modal-dialog " role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Change password</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">×</span></button>
            </div>
            <div class="modal-body">
                <form id="data-form-changePasswordAdmin">
                    {!! csrf_field() !!}
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control password" id="password" name="password" >
                    </div>
                    <div class="form-group">
                        <label for="password_confirmation ">Confirm password</label>
                        <input type="password" class="form-control password_confirmation " id="password_confirmation " name="password_confirmation" >
                    </div>
                </form>
                <div class="modal-footer ">
                    <button class="btn btn-secondary" id="closeForm" type="button" data-dismiss="modal">Close
                        <button data-link="" class="btn btn-primary" id="btn-changePasswordAdmin" name="btn-changePasswordAdmin" type="button">Update</button>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
