<div class="modal fade" id="modal-chaturbate" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Update Chaturbate</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">×</span></button>
            </div>
            <div class="modal-body">
                <form id="data-form-chaturbate">
                    {!! csrf_field() !!}
                    <div class="form-group">
                        <label for="wm">WM</label>
                        <input type="text" class="form-control wm" id="wm" name="wm" >
                    </div>
                    <div class="form-group">
                        <label for="tour">Tour</label>
                        <input type="text" class="form-control tour" id="tour" name="tour" >
                    </div>
                </form>
                <div class="modal-footer ">
                    <button class="btn btn-secondary" id="closeForm" type="button" data-dismiss="modal">Close
                        <button data-link="" class="btn btn-primary" id="btn-save" name="btn-save" type="button">Update</button>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
