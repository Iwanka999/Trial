<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog " role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Update Meta Tag</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">×</span></button>
            </div>
            <div class="modal-body">
                <form id="data-form">
                    {!! csrf_field() !!}
                    <div class="form-group">
                        <label for="description">Description</label>
                        <input type="text" class="form-control description" id="description" name="description" >
                    </div>
                    <div class="form-group">
                        <label for="keywords">Keywords</label>
                        <input type="text" class="form-control keywords" id="keywords" name="keywords" >
                    </div>
                    <div class="form-group">
                        <label for="title">Title</label>
                        <input type="text" class="form-control title" id="title" name="title" >
                    </div>
                </form>
                <div class="modal-footer ">
                    <button class="btn btn-secondary" id="closeForm" type="button" data-dismiss="modal">Close
                        <button data-link="" class="btn btn-primary" id="btn-save" name="btn-save" type="button">Update</button>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
