<div class="modal fade" id="updateAdmin" role="dialog">
    <div class="modal-dialog " role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Update Admin</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">×</span></button>
            </div>
            <div class="modal-body">
                <form id="data-form-updateAdmin">
                    {!! csrf_field() !!}
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control name" id="name" name="name" value="{{ Auth::user()->name }}" >
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="text" class="form-control email" id="email" name="email" value="{{ Auth::user()->email }}" >
                    </div>
                </form>
                <div class="modal-footer ">
                    <button class="btn btn-secondary" id="closeForm" type="button" data-dismiss="modal">Close
                        <button data-link="{{ route('admins.updateAdmin', Auth::user()->id ) }}" class="btn btn-primary editAdmin" id="btn-updateAdmin" name="btn-updateAdmin" type="button">Update</button>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
