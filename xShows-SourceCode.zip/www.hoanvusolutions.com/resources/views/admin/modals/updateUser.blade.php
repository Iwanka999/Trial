<div class="modal fade" id="updateUser" role="dialog">
    <div class="modal-dialog " role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Update User</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">×</span></button>
            </div>
            <div class="modal-body">
                <form id="data-form-updateUser">
                    {!! csrf_field() !!}
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control name" id="name" name="name" >
                    </div>
                </form>
                <div class="modal-footer ">
                    <button class="btn btn-secondary" id="closeForm" type="button" data-dismiss="modal">Close
                        <button data-link="" class="btn btn-primary" id="btn-updateUser" name="btn-updateUser" type="button">Update</button>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
