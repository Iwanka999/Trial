@extends('admin.layouts.master-admin')
@section('title', 'Setting')
@section('content')
    @include('admin.components.content-header', [
        'title' => 'Setting'
    ])
    <section class="content">
        <div class="row">
            <div class="col-12">
{{--                <form action="{{ route('settings.update') }}" method="POST" id="form-submit" enctype='multipart/form-data'>--}}
{{--                    @csrf--}}
                    <div class="card">
{{--                        <div class="card-header">--}}
{{--                            <div class="card-tools">--}}
{{--                                <button type="submit" class="btn btn-primary btn-save" >--}}
{{--                                    <i class="fa fa-save mr-2"></i>Save--}}
{{--                                </button>--}}
{{--                            </div>--}}
{{--                        </div>--}}
                        <div class="card-body">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-12">
                                        @foreach($data as $item)
                                            @switch($item->key)
                                                @case('title')
                                                    <div class="form-group row">
                                                        <label for="title" class="col-form-label col-sm-2">Title <span class="text-danger">(*)</span></label>
                                                        <div class="col-sm-8">
                                                            <input type="text" class="form-control @error('title') is-invalid @enderror" disabled
                                                                   id="title" name="title" value="{{ old('title', $item['value'] ) }}" autocomplete="off" required maxlength="255">
                                                            @error('title')
                                                            <label id="title-error" class="error" for="title">{{ $message }}</label>
                                                            @enderror
                                                        </div>
                                                    </div>
                                                    @break
                                                @case('logo')
                                                    <div class="form-group row">
                                                        <label for="logo" class="col-form-label col-sm-2">Logo <span class="text-danger">(*)</span></label>
                                                        <div class="col-sm-8">
{{--                                                            <input type="file" class="form-control logo @error('logo') is-invalid @enderror" disabled id="logo" name="logo" >--}}
{{--                                                            <br>--}}
                                                            <img class="image-in-form logo-show" src="{{ asset($item['value']) }}" >
                                                            @error('logo')
                                                            <label id="logo-error" class="error" for="logo">{{ $message }}</label>
                                                            @enderror
                                                        </div>
                                                    </div>
                                                @break
                                                @case('google_analytics_code')
                                                <div class="form-group row">
                                                    <label for="google_analytics_code" class="col-form-label col-sm-2">Google Analytics Code <span class="text-danger">(*)</span></label>
                                                    <div class="col-sm-8">
                                                        <input type="text" class="form-control @error('google_analytics_code') is-invalid @enderror" disabled
                                                               id="google_analytics_code" name="google_analytics_code" value="{{ old('google_analytics_code', $item['value'] ) }}" autocomplete="off" required maxlength="255">
                                                        @error('google_analytics_code')
                                                        <label id="google_analytics_code-error" class="error" for="google_analytics_code">{{ $message }}</label>
                                                        @enderror
                                                    </div>
                                                </div>
                                                @break
                                                @case('meta_keywords')
                                                <div class="form-group row">
                                                    <label for="meta_keywords" class="col-form-label col-sm-2">Meta tag Keywords <span class="text-danger">(*)</span></label>
                                                    <div class="col-sm-8">
                                                        <input type="text" class="form-control @error('meta_keywords') is-invalid @enderror" disabled
                                                               id="meta_keywords" name="meta_keywords" value="{{ old('meta_keywords', $item['value'] ) }}" autocomplete="off" required maxlength="255">
                                                        @error('meta_keywords')
                                                        <label id="meta_keywords-error" class="error" for="meta_keywords">{{ $message }}</label>
                                                        @enderror
                                                    </div>
                                                </div>
                                                @break
                                                @case('meta_description')
                                                <div class="form-group row">
                                                    <label for="meta_description" class="col-form-label col-sm-2">Meta tag Description <span class="text-danger">(*)</span></label>
                                                    <div class="col-sm-8">
                                                        <input type="text" class="form-control @error('meta_description') is-invalid @enderror" disabled
                                                               id="meta_description" name="meta_description" value="{{ old('meta_description', $item['value'] ) }}" autocomplete="off" required maxlength="255">
                                                        @error('meta_description')
                                                        <label id="meta_description-error" class="error" for="meta_description">{{ $message }}</label>
                                                        @enderror
                                                    </div>
                                                </div>
                                                @break
                                            @endswitch
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
{{--                </form>--}}
            </div>
        </div>
    </section>
@endsection
@section('script')
    <script src="{{ asset('/datatables/script.js') }}"></script>
    <script>
        showImage('logo');
    </script>
@endsection
