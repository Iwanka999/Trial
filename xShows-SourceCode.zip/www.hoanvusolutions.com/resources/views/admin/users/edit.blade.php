@extends('layouts.master-admin')
@section('title', 'Chỉnh sửa cửa hàng')
@section('content')
    @include('components.content-header', [
        'title' => 'Chỉnh sửa cửa hàng',
        'parents' => [
            'shops.index' => 'Danh sách cửa hàng'
        ]
    ])
    @if (isset($detail))
        <section class="content">
            <div class="row">
                <div class="col-12">
                    <form action="{{ route('shops.update', ['shop' => $detail->id]) }}" method="POST" id="form-submit">
                        @csrf
                        @method('PUT')
                        <div class="card">
                            <div class="card-header">
                                <div class="card-tools">
                                    <a href="{{ route('shops.index') }}" class="btn btn-secondary">
                                        <i class="fa fa-arrow-left mr-2"></i>Quay về
                                    </a>
                                    <button type="reset" class="btn btn-default">
                                        <i class="fa fa-redo mr-2"></i>Làm mới
                                    </button>
                                    <button type="button" class="btn btn-primary btn-save" data-type="submit">
                                        <i class="fa fa-save mr-2"></i>Lưu
                                    </button>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="form-group row">
                                                <label for="name" class="col-form-label col-sm-2">Tên cửa hàng</label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control" disabled
                                                           value="{{ old('name',$detail->name)  }}">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="phone" class="col-form-label col-sm-2">Điện thoại <span
                                                        class="text-danger">(*)</span></label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control" name="phone" id="phone"
                                                           value="{{  old('phone',$detail->phone) }}" required maxlength="20">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="name" class="col-form-label col-sm-2">Địa chỉ <span
                                                        class="text-danger">(*)</span></label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control" name="address" id="address"
                                                           value="{{ old('address',$detail->address) }}" required>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="address" class="col-form-label col-sm-2">Tỉnh / thành
                                                    phố</label>
                                                <div class="col-sm-8">
                                                    <select class="form-control select2" name="province_id" id="province_id">
                                                        @if (isset($provinces))
                                                            @foreach ($provinces as $province)
                                                                <option
                                                                    data-link="{{ route('admin.district',['province_id' => $province->id ]) }}"
                                                                    value="{{ $province->id }}" {{ $province->id == $detail->province_id ? 'selected' : '' }}>
                                                                    {{ $province->name }}
                                                                </option>
                                                            @endforeach
                                                        @endif
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="address" class="col-form-label col-sm-2">Quận / huyện</label>
                                                <div class="col-sm-8">
                                                    <select class="form-control select2" name="district_id"
                                                            data-link="{{ route('admin.ward') }}"
                                                            id="district_id">
                                                        @if (isset($districts))
                                                            @foreach ($districts as $district)
                                                                <option
                                                                    value="{{ $district->id }}" {{ $district->id == $detail->district_id ? 'selected' : '' }}>
                                                                    {{ $district->name }}
                                                                </option>
                                                            @endforeach
                                                        @endif
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="address" class="col-form-label col-sm-2">Phường / xã</label>
                                                <div class="col-sm-8">
                                                    <select class="form-control select2" name="ward_id" id="ward_id">
                                                        @if (isset($wards))
                                                            @foreach ($wards as $ward)
                                                                <option
                                                                    value="{{ $ward->id }}" {{ $ward->id == $detail->ward_id ? 'selected' : '' }}>
                                                                    {{ $ward->name }}
                                                                </option>
                                                            @endforeach
                                                        @endif
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="address" class="col-form-label col-sm-2">Tọa độ</label>
                                                <div class="col-sm-8">
                                                    <div class="row">
                                                        <div class="col-sm-6">
                                                            <label for="latitude" class="col-form-label col-sm-3">Vĩ
                                                                độ</label>
                                                            <input type="text" class="form-control" id="latitude"
                                                                   name="latitude"
                                                                   value="{{ old('latitude',$detail->latitude) }}">
                                                        </div>
                                                        <div class="col-sm-6">
                                                            <label for="longitude" class="col-form-label col-sm-3">Kinh
                                                                độ</label>
                                                            <input type="text" class="form-control" id="longitude"
                                                                   name="longitude"
                                                                   value="{{  old('longitude',$detail->longitude) }}">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                    </form>
                </div>
            </div>
        </section>
    @endif
@endsection
@section('script')
    <script src="{{ asset('static/backend/js/shop/shop.js?v='.time()) }}"></script>
    <script src="{{ asset('static/backend/js/shop/shopPagination.js?v='.time()) }}"></script>
    <script>
        const shop = new Shop("{{ route('shops.index') }}")
        shop.changeLocation()
        shop.save()
    </script>
@endsection
