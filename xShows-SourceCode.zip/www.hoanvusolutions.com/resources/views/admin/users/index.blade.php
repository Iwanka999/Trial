@extends('admin.layouts.master-admin')
@section('title', 'Users')
@section('content')
    @include('admin.components.content-header', ['title' => 'Users'])
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <form action="" method="get" id="form-filter">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Users</h3>
{{--                                <div class="card-tools">--}}
{{--                                    <a href="{{ route('users.create') }}" class="btn btn-info">Add</a>--}}
{{--                                </div>--}}
                            </div>
                            <div class="card-body table-responsive p-0" style="max-height: 740px">
                                <table class="table table-hover table-head-fixed text-nowrap" id="data-datatables">
                                    <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    @include('admin.modals.changePassword')
    @include('admin.modals.updateUser')

@endsection
@section('script')
    <script src="{{ asset('/datatables/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('/datatables/script.js') }}"></script>
    <script src="{{ asset('/static/backend/js/user.js') }}"></script>

    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        var oTable = dataTables('{!! route('users.datatables') !!}', [
            {data: 'id', name: 'id', width: "7%", "className": "text-center"},
            {data: 'name', name: 'name', "className": "text-center"},
            {data: 'email', name: 'email', "className": "text-center"},
            {data: 'status', name: 'status', "className": "text-center",searchable: false},
            {
                data: 'action',
                name: 'action',
                orderable: false,
                searchable: false,
                "className": "text-center",
                width: "11%",
            }
        ]);
        // $("#data-datatables_filter").hide();
        $('#search-form').on('submit', function (e) {
            oTable.draw();
            e.preventDefault();
        });
     </script>
@endsection
