<video
    controls
    id="video"
    title="Advertisement"
    style="background-color: rgb(0, 0, 0); position: absolute; height: 100%;"
    data-src="{{ $link }}"
    autoplay="true"
    playsinline
    muted="muted"></video>

@push('scripts')
    <script>
        var video = document.getElementById('video');
        var videoSrc = video.getAttribute('data-src');
        // First check for native browser HLS support
        //
        if (video.canPlayType('application/vnd.apple.mpegurl')) {
            video.src = videoSrc;
            video.addEventListener('loadedmetadata', function() {
                video.play();
            });
            //
            // If no native HLS support, check if hls.js is supported
            //
        } else if (Hls.isSupported()) {
            var hls = new Hls();
            hls.loadSource(videoSrc);
            hls.attachMedia(video);
            hls.on(Hls.Events.MANIFEST_PARSED, function() {
                video.play();
            });
        }
    </script>
@endpush
