{{--<div id="domToInjectTheWidgetda1iuumu58t"></div>--}}
{{--<script type="text/javascript">if (promotoolWidget === undefined) {--}}
{{--        var promotoolWidget = document.createElement("script");--}}
{{--        promotoolWidget.setAttribute("type", "text/javascript");--}}
{{--        promotoolWidget.setAttribute("src", "https://prm03.wlresources.com/static/js/app/widget.js?167298");--}}
{{--        document.head.appendChild(promotoolWidget);--}}
{{--    }--}}
{{--    window.addEventListener("XlovepromotoolInit", function (event) {--}}
{{--        var config = {--}}
{{--            "ui": {--}}
{{--                "id_affilie": "{{ $idAffilie }}",--}}
{{--                "cf": "990000",--}}
{{--                "caf": "7c747c7d",--}}
{{--                "cac": "fff",--}}
{{--                "tlt": "7f0000",--}}
{{--                "cc": "990000",--}}
{{--                "ct": "fff",--}}
{{--                "ca": "99000082",--}}
{{--                "trac": "{{ $idAffilie }}",--}}
{{--                "psm": "{{ $nickName }}",--}}
{{--                "iframeVersion": false,--}}
{{--                "displayLogo": false,--}}
{{--                "quickFilters": false,--}}
{{--                "topLinks": false,--}}
{{--                "modelSuggestion": false,--}}
{{--                "textChat": false,--}}
{{--                "linkNewPage": false,--}}
{{--                "tri": 10--}}
{{--            },--}}
{{--            "domId": "domToInjectTheWidgetda1iuumu58t",--}}
{{--            "resourcesUrl": "https://s4.wlresources.com",--}}
{{--            "promotoolUrl": "https://prm03.wlresources.com",--}}
{{--            "cacheBuster": "167298"--}}
{{--        };--}}
{{--        Xlovepromotool.WidgetFactory.create("LiveChat", config).init();--}}
{{--    });--}}
{{--</script>--}}
{{--<iframe src="https://prm03.wlresources.com/livechatiframe?d=" scrolling="no" frameborder="0" style="overflow: hidden;" height="100%" width="100%"></iframe>--}}

<iframe src="{{$link}}" scrolling="no" frameborder="0" style="overflow: hidden;" height="100%" width="100%"></iframe>
