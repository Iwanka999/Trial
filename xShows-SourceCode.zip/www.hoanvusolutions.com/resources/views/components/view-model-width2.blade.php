<div class="grid-item grid-item--width2">
    <a href="{{ route('detailPage',['uniqueUsername' => $model->unique_user_name ] ) }}" class="item-model ad-model">
        @if($model['is_online'])
        <div class="img-cover">
            {!!  handleLiveChat($model) !!}
        </div>
        @elseif($model['source'] == \App\Models\Config::CHATURBATE)
            <div class="img-cover chaturbate" style="background-image:url('{{ asset($logo_global) }}')">
                <img src='{{ asset($logo_global) }}'>
            </div>
        @else
            <div class="img-cover" style="background-image:url('{{ $model['image'] }}')">
                <img src='{{ $model['image'] }}'>
            </div>
        @endif

        <div class="txt-ad-model">
            <h3>{{$model['display_name']}}</h3>
            @if($model['is_online'])
            <div class="live-m">Live</div>
            @endif
        </div>
        {{--                                <span class="mute"><i class="fas fa-volume-mute"></i></span>--}}
    </a>
</div>
