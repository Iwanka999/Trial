<div class="grid-item">
    <a href="{{ route('detailPage',['uniqueUsername' => $model->unique_user_name ]  ) }}" class="item-model">
        @if(!$model['is_online'] && $model['source'] == \App\Models\Config::CHATURBATE)
            <div class="img-cover chaturbate" style="background-image:url('{{ asset($logo_global) }}')">
                <img src='{{ asset($logo_global) }}'>
            </div>
        @else
            <div class="img-cover" style="background-image:url('{{ $model["image"] }}')">
                <img src='{{ $model['image'] }}'>
            </div>
        @endif

        <div class="txt-model favourite" data-url="{{ route('attachFavourite',$model['id']) }}" data-model-id="{{ $model['id'] }}">
            <h3 class="status  {{ ($model['is_online']) ? 'online' : 'offline' }}">{{ $model['display_name'] }}</h3>
            <div class="fav-model  {{ ($model['favourite'] ? 'active' : '') }}">
                {{--                                        <span>90%</span>--}}
                <i class="fas fa-heart "></i>
            </div>
        </div>
    </a>
</div>
