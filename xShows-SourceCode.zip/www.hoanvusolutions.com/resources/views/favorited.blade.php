@extends('index')
@section('content')

    <div class="content-inner">
        <div class="title-b">{{ __('My Favorites') }}</div>
        <div class="grid">
            @foreach($data as $key => $model)
                @include('components.view-model')
{{--                <div class="grid-item">--}}
{{--                    <a href="{{  route('detailPage',['id' => $model->id] ) }}" class="item-model">--}}
{{--                        <div class="img-cover" style="background-image:url('{{ $model["image"] }}')">--}}
{{--                            <img src='{{ $model['image'] }}'>--}}
{{--                        </div>--}}
{{--                        <div class="txt-model favourite" data-url="{{ route('attachFavourite',$model['id']) }}"--}}
{{--                             data-model-id="{{ $model['id'] }}">--}}
{{--                            <h3 class="status  {{ ($model['is_online']) ? 'online' : 'offline' }}">{{ $model['display_name'] }}</h3>--}}
{{--                            <div class="fav-model  {{ ($model['favourite'] ? 'active' : '') }}">--}}
{{--                                --}}{{--                                        <span>90%</span>--}}
{{--                                <i class="fas fa-heart"></i>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </a>--}}
{{--                </div>--}}
            @endforeach
        </div>
        <nav aria-label="Page navigation example" class="sub-page">
            {{ $data->links() }}
        </nav>
    </div>

@endsection

