<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="@yield('meta_description_global', $meta_description_global)">
    <meta name="keywords" content="@yield('meta_keywords_global', $meta_keywords_global)">
    <meta property="og:url" content="{{ request()->fullUrl() }}">
    <meta property="og:image" content="@yield('logo_global', $logo_global)">
    <meta property="og:title" content="@yield('meta_title_global', $title_global)">
    <meta property="og:description" content="@yield('meta_description_global', $meta_description_global)">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', $title_global)</title>

    <link href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,400;0,700;1,400;1,700&display=swap"
          rel="stylesheet">
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="{{asset('/css/bootstrap.css') }}">
    <link rel="stylesheet" href="{{asset('/font-awesome/css/all.css') }}">

    <!-- Custom styles for this template -->
    <link rel="stylesheet" href="{{asset('/css/style.css') }}">
    <link rel="stylesheet" href="{{asset('/css/responsive.css') }}">

    <link href="{{asset('alertify/css/alertify.min.css')}}" id='aleritify_ds' rel="stylesheet">
    <link href="{{asset('alertify/css/themes/bootstrap.min.css')}}" id='aleritify_s' rel="stylesheet">
    <!-- Javascript -->
    <script src="{{ asset('js/hls.js') }}"></script>

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id={{ $google_analytics_code_global }}"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', '{{ $google_analytics_code_global }}');
    </script>
<body>

@include('layouts.header')
<div class="bg-cate"></div>

@yield('content')

<footer>
    <div class="copyright">2020 - Xshow. All rights reserved.</div>
</footer>

<meta name="csrf-token" content="{{ csrf_token() }}">
<script src="{{asset('/js/jquery.min.js')}}" type="text/javascript"></script>

<script src="{{asset('/js/masonry.min.js')}}"></script>
<script src="{{asset('/js/main.js')}}"></script>
<script src="{{asset('/alertify/alertify.min.js')}}" type="text/javascript"></script>

@stack('scripts')
</body>
</html>
