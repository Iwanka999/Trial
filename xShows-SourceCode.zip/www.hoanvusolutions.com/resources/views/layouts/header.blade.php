<header class="header">
    <div class="logo">
        <a href="{{route('home')}}">
            <img src="{{asset($logo_global)}}">
        </a>
    </div>
    <div class="right-header">
        <ul class="menu">
            <li class="{{ Request::is('*/trans')  ? ' active' : '' }}"><a href="{{ route('sexPage','trans') }}">{{ __('TRANS') }}</a></li>
            <li class="{{ Request::is('*/male')  ? ' active' : '' }}"><a href="{{ route('sexPage','male') }}">{{ __('BOYS') }}</a></li>
            <li class="{{ Request::is('*/female')  ? ' active' : '' }}"><a href="{{ route('sexPage','female') }}">{{ __('GIRLS') }}</a></li>
            @guest
            <li><a href="{{ route('register') }}" class="btn btn-danger">{{ __('Register') }}</a></li>
            <li><a href="{{ route('login') }}" class="btn btn-dark">{{ __('Login') }}</a></li>
            @else
                <li  class="{{ Request::is('*/favorites')  ? ' active' : '' }}"><a href="{{ route('favorites') }}">{{ __('FAVORITES') }}</a></li>
                <li><a href="#" class="btn btn-dark">{{ __('Welcome') }}, {{ Auth::user()->name }}</a></li>
                <li><a href="{{ route('logout') }}">{{ __('LOGOUT') }}</a></li>
            @endguest
        </ul>
    </div>
    <div class="category-m">Categories</div>
    <div class="toogle-a"><span></span><span></span><span></span></div>
</header>
