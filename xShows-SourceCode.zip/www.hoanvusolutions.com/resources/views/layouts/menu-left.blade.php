<div class="menu-left">
    <ul>
        @foreach($categories as $cate)
        <li>
            <a href="{{ route('home',['cate' => $cate->name, 'sex' => request()->route('sex') ]) }}">{{ $cate->display_name }}</a>
        </li>
        @endforeach
    </ul>
</div>
