<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


//Auth::routes();
Route::group(['namespace' => 'Admin', 'prefix' => 'admin'], function () {

    Route::get('login', 'Auth\LoginController@showLoginForm')->name('admin.login');
    Route::post('login', 'Auth\LoginController@login')->name('admin.login');
    Route::get('logout', 'Auth\LoginController@logout')->name('logout');

    Route::group(['middleware' => ['check_admin']], function () {

        Route::get('/', 'AdminController@home')->name('admin.home');
        Route::group(['prefix' => 'configs'], function () {
            Route::patch('/{id}', 'AdminController@updateStatus')->name('config.updates-status');
//            Route::get('user', 'AdminController@index')->name('user.list');

            Route::get('/{id}', 'AdminController@edit')->name('config.edit');
            Route::put('/{id}', 'AdminController@update')->name('config.update');
        });

        Route::get('categories', 'CategoryController@index')->name('categories.index');
        Route::match(array('GET','POST'),'categories/data', 'CategoryController@index')->name('categories.datatables');
        Route::patch('categories/{id}', 'CategoryController@updateStatus')->name('categories.updates-status');

        Route::get('categories/{id}', 'CategoryController@edit')->name('categories.edit');
        Route::put('categories/{id}', 'CategoryController@update')->name('categories.update');

        Route::match(array('GET','POST'),'shops/data', 'ShopsController@index')->name('shops.datatables');
        Route::resource('shops', 'ShopsController');

        Route::match(array('GET','POST'),'users/data', 'UserController@index')->name('users.datatables');
        Route::patch('users/{id}/restore', 'UserController@restore')->name('users.restore');
        Route::patch('users/{id}/cp', 'UserController@changePassword')->name('users.changePassword');
        Route::resource('users', 'UserController');

        Route::patch('admins/cpa', 'UserController@changePasswordAdmin')->name('admins.changePasswordAdmin');
        Route::patch('admins', 'UserController@updateAdmin')->name('admins.updateAdmin');

        Route::get('settings', 'SettingController@edit')->name('settings.edit');
        Route::post('settings', 'SettingController@update')->name('settings.update');
    });
});

// Authentication Routes...
Route::get('login', 'Auth\LoginController@showLoginForm')->name('login');
Route::post('login', 'Auth\LoginController@login');
Route::get('logout', 'Auth\LoginController@logout')->name('logout');

// Registration Routes...
Route::get('register', 'Auth\RegisterController@showRegistrationForm')->name('register');
Route::post('register', 'Auth\RegisterController@register');

// Password Reset Routes...
Route::get('password/reset', 'Auth\ForgotPasswordController@showLinkRequestForm')->name('password.request');
Route::post('password/email', 'Auth\ForgotPasswordController@sendResetLinkEmail')->name('password.email');
Route::get('password/reset/{token}', 'Auth\ResetPasswordController@showResetForm')->name('password.reset');
Route::post('password/reset', 'Auth\ResetPasswordController@reset')->name('password.update');

// Confirm Password (added in v6.2)
Route::get('password/confirm', 'Auth\ConfirmPasswordController@showConfirmForm')->name('password.confirm');
Route::post('password/confirm', 'Auth\ConfirmPasswordController@confirm');

// Email Verification Routes...
Route::get('email/verify', 'Auth\VerificationController@show')->name('verification.notice');
Route::get('email/verify/{id}/{hash}', 'Auth\VerificationController@verify')->name('verification.verify'); // v6.x
/* Route::get('email/verify/{id}', 'Auth\VerificationController@verify')->name('verification.verify'); // v5.x */
Route::get('email/resend', 'Auth\VerificationController@resend')->name('verification.resend');

Route::group(array('middleware' => 'auth'), function () {
    Route::post('/favourites/{id}', 'HomeController@attachFavourite')->name('attachFavourite');
    Route::get('/favorites', 'HomeController@favorites')->name('favorites');
});

Route::get('/gender/{sex}', 'HomeController@sex')->name('sexPage');
Route::get('/chat/{uniqueUsername}', 'HomeController@detail')->name('detailPage');
Route::get('/{id}/related', 'HomeController@ajaxRelated')->name('ajaxRelated');
Route::get('/{cate?}', 'HomeController@index')->name('home');
